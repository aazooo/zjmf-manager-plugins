<?php

return [
    'amount' => [
        'title' => '金额',
        'type' => 'text',
        'value' => 0,
        'tip' => '支付金额'
    ],
    'free' => [
        'title' => '免费认证次数',
        'type' => 'text',
        'value' => 0,
        'tip' => '免费认证次数'
    ],
    'app_code' => [
        'title' => 'appCode',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ]
];