<?php
return ["amount" => ["title" => "金额", "type" => "text", "value" => 0, "tip" => "支付金额"], "free" => ["title" => "免费认证次数", "type" => "text", "value" => 0, "tip" => "免费认证次数"], "app_code" => ["title" => "appCode", "type" => "text", "value" => "", "tip" => ""], "type" => ["title" => "认证方式", "type" => "select", "options" => ["2" => "两要素", "3" => "三要素", "4" => "四要素"], "value" => "2", "tip" => "认证方式"]];

?>