<?php
return ["threehc_url" => "https://api11.aliyun.venuscn.com", "app_code" => ""];

?>