<?php

return [
    'SmsSdkAppId' => [
        'title' => 'SmsSdkAppId ID',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'AppKey' => [
        'title' => 'AppKey Secret',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'SecretId' => [
        'title' => 'SecretId ID',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'SecretKey' => [
        'title' => 'SecretKey Secret',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'SignName' => [
        'title' => '短信签名',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ]
];
