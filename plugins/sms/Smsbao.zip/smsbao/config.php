<?php

return [
    'user' => [
        'title' => '短信平台帐号',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'pass' => [
        'title' => '短信平台密码',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'sign' => [
        'title' => '短信宝SignName',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ]
];