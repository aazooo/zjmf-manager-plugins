<?php
return ["user" => ["title" => "appKey", "type" => "text", "value" => "", "tip" => ""], "pass" => ["title" => "appCode", "type" => "text", "value" => "", "tip" => ""], "secret" => ["title" => "appSecret", "type" => "text", "value" => "", "tip" => ""], "sign" => ["title" => "SignName", "type" => "text", "value" => "", "tip" => ""]];

?>