<?php
return ["user" => ["title" => "用户名", "type" => "text", "value" => "", "tip" => ""], "pass" => ["title" => "key", "type" => "text", "value" => "", "tip" => ""], "sign" => ["title" => "签名", "type" => "text", "value" => "", "tip" => ""]];

?>