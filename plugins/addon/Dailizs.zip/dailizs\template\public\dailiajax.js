
function qx(){   //全选
    $(":checkbox").prop("checked",true );
 }
 function checkNo(){  //不选
    $(":checkbox").prop("checked",false);
 }
 function reves(){  //反选
    $.each($(":checkbox"),function(){
        $(this).prop("checked",!$(this).prop("checked"));
    });
 }
 function 更新库存() {
    var ids = '';
    $('.checkbox').each(function () {
        if ($(this).is(':checked')) {
            ids += ',' + $(this).val(); //逐个获取id
        }
    })
    ids = ids.substring(1); // 对id进行处理，去除第一个逗号
    if (ids.length == 0) {
        layer.msg('请选择要同步的选项');
    }else{
        layer.confirm('确定要同步吗？', {
            btn: ['确定', '取消'] //按钮
        }, function () {
            $.ajax({
                type: 'get',
                url: '{:shd_addon_url('Dailizs://AdminIndex/gxkc')}',
                data: "ids=" + ids,
                dataType: 'json',
                success: function (res) {
                    if (res.code == '1') {
                        layer.msg(res.msg, {icon: 1, time: 2000});
                        setTimeout(function () {
                            window.location.reload();
                        }, 3000)
                    } else {
                        layer.msg(res.msg, {icon: 5})
                    }
                }
            })
        }, function () {
 
        });
    }
 
 }
 
 
 function 还原库存() {
    var ids = '';
    $('.checkbox').each(function () {
        if ($(this).is(':checked')) {
            ids += ',' + $(this).val(); //逐个获取id
        }
    })
    ids = ids.substring(1); // 对id进行处理，去除第一个逗号
    if (ids.length == 0) {
        layer.msg('请选择要还原的选项');
    }else{
        layer.confirm('确定要还原吗？', {
            btn: ['确定', '取消'] //按钮
        }, function () {
            $.ajax({
                type: 'get',
                url: '{:shd_addon_url('Dailizs://AdminIndex/hy')}',
                data: "ids=" + ids,
                dataType: 'json',
                success: function (res) {
                    if (res.code == '1') {
                        layer.msg(res.msg, {icon: 1, time: 2000});
                        setTimeout(function () {
                            window.location.reload();
                        }, 3000)
                    } else {
                        layer.msg(res.msg, {icon: 5})
                    }
                }
            })
        }, function () {
 
        });
    }
 
 }
 function 一键同步() {
        layer.confirm('确定要一键同步吗？', {
            btn: ['确定', '取消'] //按钮
        }, function () {
            $.ajax({
                type: 'get',
                url: '{:shd_addon_url('Dailizs://AdminIndex/yjgx')}',
                data: "",
                dataType: 'json',
                success: function (res) {
                    if (res.code == '1') {
                        layer.msg(res.msg, {icon: 1, time: 2000});
                        setTimeout(function () {
                            window.location.reload();
                        }, 3000)
                    } else {
                        layer.msg(res.msg, {icon: 5})
                    }
                }
            })
        }, function () {
 
        });
    }
 function 一键还原() {
        layer.confirm('确定要全部还原吗？', {
            btn: ['确定', '取消'] //按钮
        }, function () {
            $.ajax({
                type: 'get',
                url: '{:shd_addon_url('Dailizs://AdminIndex/yjhy')}',
                data: "",
                dataType: 'json',
                success: function (res) {
                    if (res.code == '1') {
                        layer.msg(res.msg, {icon: 1, time: 2000});
                        setTimeout(function () {
                            window.location.reload();
                        }, 3000)
                    } else {
                        layer.msg(res.msg, {icon: 5})
                    }
                }
            })
        }, function () {
 
        });
    }