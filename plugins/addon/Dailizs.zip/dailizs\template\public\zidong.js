
function dlzscfjs() {
    var ids = document.getElementById("keyjs").value;
    
    if (ids.length == 0 ) {
        layer.msg('请输入key');
    }else{
        layer.confirm('确定要修改吗？', {
            btn: ['确定', '取消'] //按钮
        }, function () {
            $.ajax({
                type: 'get',
                url: '{:shd_addon_url('Dailizs://AdminIndex/dlzscf')}',
                data: "ids=" + ids,
                dataType: 'json',
                success: function (res) {
                    if (res.code == '1') {
                        layer.msg(res.msg, {icon: 1, time: 2000});
                        setTimeout(function () {
                            window.location.reload();
                        }, 3000)
                    } else {
                        layer.msg(res.msg, {icon: 5})
                    }
                }
            })
        }, function () {
 
        });
    }
 
 }