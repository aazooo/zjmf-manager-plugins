<?php
return [["name" => "域名白名单", "url" => "QingYeIcp://Index/icp", "fa_icon" => "bx bxs-user-detail"]];

?>