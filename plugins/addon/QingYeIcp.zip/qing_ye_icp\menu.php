<?php
return [["name" => "设置", "url" => "QingYeIcp://AdminIndex/setting", "custom" => 0]];

?>