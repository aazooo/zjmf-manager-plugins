<?php
return [["name" => "功能设置", "url" => "DeleteUser://AdminIndex/setting", "custom" => 0, "lang" => ["chinese" => "功能设置", "chinese_tw" => "功能設置", "english" => "Setting"]], ["name" => "申请列表", "url" => "DeleteUser://AdminIndex/lists", "custom" => 0, "lang" => ["chinese" => "申请列表", "chinese_tw" => "申請列表", "english" => "List"]]];

?>