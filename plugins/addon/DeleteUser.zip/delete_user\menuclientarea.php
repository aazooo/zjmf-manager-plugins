<?php
return [["name" => "自助删除账号", "url" => "", "fa_icon" => "bx bx-no-entry", "lang" => ["chinese" => "自助删除账号", "chinese_tw" => "自助刪除賬號", "english" => "Delete Account"], "child" => [["name" => "自助删除", "url" => "DeleteUser://Index/check", "fa_icon" => "bx bx-unlink", "lang" => ["chinese" => "账号删除", "chinese_tw" => "賬號刪除", "english" => "Delete Account"], "child" => []]]]];

?>