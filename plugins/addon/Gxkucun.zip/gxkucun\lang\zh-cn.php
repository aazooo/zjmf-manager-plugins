<?php
return ["CLIENT_CARE_AFTER_ORDER_PORDUCT" => "", "ACCEPT" => ""];

?>