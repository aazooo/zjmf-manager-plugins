<?php
namespace addons\gxkucun;

class GxkucunPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "Gxkucun", "title" => "自动同步上游库存", "description" => "一键同步上游库存,在前台显示库存,支持挂任务自动更新", "status" => 1, "author" => "飞凤互联", "version" => "1.1.0", "module" => "addons", "lang" => ["chinese" => "自动同步上游库存", "chinese_tw" => "自动同步上游库存", "english" => "zidongtongbushangyoukucun"]];
    public function install()
    {
        $DbConfig = \Think\Db::getConfig();
        $CacheDbName = $DbConfig["prefix"] . "dailizs";
        $database = (string) $DbConfig["database"];
        $tableLista = \Think\Db::query("SELECT table_name FROM information_schema.TABLES WHERE TABLE_SCHEMA='" . $DbConfig["database"] . "'");
        $tableList = array_column($tableLista, "table_name");
        if (!in_array($CacheDbName, $tableList)) {
            $an = \Think\Db::query("CREATE TABLE  `" . $CacheDbName . "`  ( `id` INT(10) NOT NULL AUTO_INCREMENT , `sl` INT(11) NOT NULL , `time` VARCHAR(255) NULL ,`key` VARCHAR(255) NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB");
        }
        $CacheDbNamecf = $DbConfig["prefix"] . "dailizs_cf";
        if (!in_array($CacheDbNamecf, $tableList)) {
            $cf = \Think\Db::query("CREATE TABLE  `" . $CacheDbNamecf . "`  ( `id` INT(10) NOT NULL AUTO_INCREMENT , `ffidc` VARCHAR(255)  NULL , `time` VARCHAR(255) NULL ,`key` VARCHAR(255) NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB");
        }
        if ($an !== NULL && $cf !== NULL) {
            $ffidc = $_SERVER["HTTP_HOST"];
            $ffkey = "dailizs";
            $time = time();
            $ccf = \Think\Db::query("INSERT INTO `" . $CacheDbNamecf . "` (`id`, `ffidc`, `time`, `key`) VALUES (NULL, '" . $ffidc . "', '" . $time . "', '" . $ffkey . "')");
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
    public function clientLogin()
    {
    }
    public function templateAfterServicedetailSuspended($param)
    {
        return "";
    }
}

?>