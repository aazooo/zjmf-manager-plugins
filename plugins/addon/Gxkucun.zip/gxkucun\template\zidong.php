<?php
$cf = (include "../../app/config/database.php");
$servername = $cf["hostname"];
$username = $cf["username"];
$password = $cf["password"];
$dbname = $cf["database"];
$db_prefix = $cf["prefix"];
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    exit("数据库连接失败: " . $conn->connect_error);
}
$arr = $_SERVER;
$url = $arr["QUERY_STRING"];
$urlkey = substr($url, 4);
$sqlkey = "SELECT * FROM `" . $db_prefix . "dailizs_cf` WHERE `id`";
$resultkey = $conn->query($sqlkey);
$rowkey = $resultkey->fetch_assoc();
if ($urlkey !== $rowkey["key"]) {
    $jgjson = ["code" => "0", "msg" => "key不正确！"];
    echo json_encode($jgjson, JSON_UNESCAPED_UNICODE);
    exit;
}
$time = time();
$stock = "UPDATE `" . $db_prefix . "products` set `stock_control`=`upstream_stock_control`, `qty`=`upstream_qty` WHERE `upstream_stock_control`=1";
$resultst = $conn->query($stock);
if ($resultst) {
    $num = $conn->affected_rows;
    if (0 < $num) {
        $dlzs = "INSERT INTO `shd_dailizs` (`id`, `sl`, `time`, `key`) VALUES (NULL, '" . $num . "', '" . $time . "', '1')";
        $resdizs = $conn->query($dlzs);
        if ($resdizs) {
            $jgjson = ["code" => "1", "msg" => "更新成功" . $num . "条！"];
            echo json_encode($jgjson, JSON_UNESCAPED_UNICODE);
        }
    } else {
        $dlzs = "INSERT INTO `shd_dailizs` (`id`, `sl`, `time`, `key`) VALUES (NULL, '0', '" . $time . "', '0')";
        $resdizs = $conn->query($dlzs);
        $jgjson = ["code" => "0", "msg" => "没有更新的数据"];
        echo json_encode($jgjson, JSON_UNESCAPED_UNICODE);
    }
}
$conn->close();

?>