<?php

return [
    [
        'name' => '导出列表',
        'url' => 'ExportExcel://AdminIndex/index',
        'custom' => 0
    ]
];
