<?php
namespace addons\internal_information;

class InternalInformationPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "InternalInformation", "title" => "站内信", "description" => "给用户发送站内信通知", "status" => 1, "author" => "<a href=\"http://www.yunbuyun.com\">云步云计算</a>", "version" => "1.0.5", "module" => "addons", "lang" => ["chinese" => "站内信", "chinese_tw" => "站內信", "english" => "internal information"]];
    public function install()
    {
        $fieldsToAddTable1 = [["name" => "id", "type" => "INT AUTO_INCREMENT PRIMARY KEY"], ["name" => "apiid", "type" => "VARCHAR(255)"], ["name" => "apikey", "type" => "VARCHAR(255)"], ["name" => "weburl", "type" => "VARCHAR(255)"], ["name" => "zzemail", "type" => "TINYINT NOT NULL"], ["name" => "zzqq", "type" => "TINYINT NOT NULL"], ["name" => "mfauth", "type" => "TINYINT NOT NULL"]];
        $tableName1 = "shd_internal_information";
        $tableExists1 = \think\db::query("SHOW TABLES LIKE '" . $tableName1 . "'");
        if (empty($tableExists1)) {
            $sql1 = "\n            CREATE TABLE " . $tableName1 . " (\n                " . implode(",\n", array_map(function ($fieldInfo) {
                return $fieldInfo["name"] . " " . $fieldInfo["type"] . " COMMENT '" . $fieldInfo["comment"] . "'";
            }, $fieldsToAddTable1)) . "\n            );\n        ";
            \think\db::execute($sql1);
        } else {
            foreach ($fieldsToAddTable1 as $fieldInfo) {
                $fieldName = $fieldInfo["name"];
                $fieldExists = \think\db::query("SHOW COLUMNS FROM " . $tableName1 . " LIKE '" . $fieldName . "'");
                if (empty($fieldExists)) {
                    $sql1 = "\n                    ALTER TABLE " . $tableName1 . "\n                    ADD COLUMN " . $fieldInfo["name"] . " " . $fieldInfo["type"] . " COMMENT '" . $fieldInfo["comment"] . "';\n                ";
                    \think\db::execute($sql1);
                }
            }
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
    public function client()
    {
        return "";
    }
    public function Login()
    {
        return "";
    }
    public function clients()
    {
        return "";
    }
    public function clientsd()
    {
        return "";
    }
}

?>