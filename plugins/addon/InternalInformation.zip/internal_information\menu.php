<?php
return [["name" => "系统设置", "url" => "InternalInformation://AdminIndex/setting", "custom" => 0, "lang" => ["chinese" => "系统设置", "chinese_tw" => "系統設置", "english" => "System settings"]], ["name" => "发送站内信", "url" => "InternalInformation://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "发送站内信", "chinese_tw" => "發送站內信", "english" => "Send internal messages"]]];

?>