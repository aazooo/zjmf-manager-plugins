<?php
namespace addons\product_date;

class ProductDatePlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "ProductDate", "title" => "批量调整机器时间", "description" => "适合自营产品补时操作", "status" => 1, "author" => "GZHX Technology", "version" => "1.0.0", "module" => "addons", "update_description" => "批量调整机器时间", "not_install" => true];
    public function install()
    {
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>