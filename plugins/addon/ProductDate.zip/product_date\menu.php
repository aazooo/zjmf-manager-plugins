<?php
return [["name" => "时间调整", "url" => "ProductDate://AdminIndex/index", "custom" => 0]];

?>