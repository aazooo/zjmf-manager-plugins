<?php
return [["name" => "同步日志", "url" => "SyncInventory://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "同步日志", "chinese_tw" => "同步日志", "english" => "Sync Log"]]];

?>