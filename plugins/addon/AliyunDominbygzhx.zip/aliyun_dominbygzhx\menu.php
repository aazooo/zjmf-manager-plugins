<?php
return [["name" => "销售设置", "url" => "AliyunDominbygzhx://AdminIndex/index", "custom" => 0]];

?>