<?php
return [["name" => "防火墙管理", "url" => "QingYeFirewall://Index/cc", "fa_icon" => "bx bxs-grid-alt"]];

?>