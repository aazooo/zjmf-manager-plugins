<?php
return [["name" => "设置", "url" => "QingYeFirewall://AdminIndex/setting", "custom" => 0]];

?>