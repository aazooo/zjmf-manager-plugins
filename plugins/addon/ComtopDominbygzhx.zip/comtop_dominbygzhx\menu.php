<?php
return [["name" => "销售设置", "url" => "ComtopDominbygzhx://AdminIndex/index", "custom" => 0]];

?>