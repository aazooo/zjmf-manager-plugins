<?php
namespace addons\comtop_dominbygzhx;

class ComtopDominbygzhxPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "ComtopDominbygzhx", "title" => "中国数据域名注册", "description" => "中国数据域名注册", "status" => 1, "author" => "GZHX Technology", "version" => "1.0.4", "update_description" => "增加中文域名支持,增加隐藏选项", "module" => "addons", "not_install" => true];
    public $robotConfig;
    public function install()
    {
        $DbConfig = \Think\Db::getConfig();
        $CacheDbName = $DbConfig["prefix"] . "gzhx_domain";
        $SettingDBName = $DbConfig["prefix"] . "gzhx_domain_error";
        $DomainDBName = $DbConfig["prefix"] . "gzhx_domain_template";
        $tableList = \Think\Db::query("SELECT table_name FROM information_schema.TABLES WHERE TABLE_SCHEMA='" . $DbConfig["database"] . "'");
        $tableList = array_column($tableList, "table_name");
        if (!in_array($CacheDbName, $tableList)) {
            \Think\Db::query("CREATE TABLE `" . $CacheDbName . "`  (`id` int(11) NOT NULL AUTO_INCREMENT,`domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`start_time` datetime(0) NULL DEFAULT NULL,`end_time` datetime(0) NULL DEFAULT NULL,`uid` int(11) NULL DEFAULT 0,`api_id` int(11) NULL DEFAULT 0,`vid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`active` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '正常',`years` tinyint(3) NULL DEFAULT 1,`templete_info` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`task_id` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`last_update` datetime(0) NULL DEFAULT '2000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP(0),PRIMARY KEY (`id`) USING BTREE,INDEX `domain`(`domain`) USING BTREE,INDEX `api_id`(`api_id`) USING BTREE,INDEX `uid`(`uid`) USING BTREE,INDEX `vid`(`vid`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;");
        }
        if (!in_array($SettingDBName, $tableList)) {
            \Think\Db::query("CREATE TABLE `" . $SettingDBName . "`  (`id` int(11) NOT NULL AUTO_INCREMENT,`aid` int(11) NULL DEFAULT 0,`type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`msg` varchar(4000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`add_time` datetime(0) NULL DEFAULT NULL,`status` int(5) NULL DEFAULT 1,`domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`api_id` int(11) NULL DEFAULT 0,`op` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,PRIMARY KEY (`id`) USING BTREE,INDEX `domain`(`aid`) USING BTREE,INDEX `api_id`(`add_time`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;");
        }
        if (!in_array($DomainDBName, $tableList)) {
            \Think\Db::query("CREATE TABLE `" . $DomainDBName . "`  (`id` int(11) NOT NULL AUTO_INCREMENT,`domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`organization_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`certificate_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`uid` int(11) NULL DEFAULT 0,`api_id` int(11) NULL DEFAULT 0,`vid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`config` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,`status` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`last_update` datetime(0) NULL DEFAULT '2000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP(0),PRIMARY KEY (`id`) USING BTREE,INDEX `domain`(`domain`) USING BTREE,INDEX `api_id`(`api_id`) USING BTREE,INDEX `uid`(`uid`) USING BTREE,INDEX `vid`(`vid`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;");
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>