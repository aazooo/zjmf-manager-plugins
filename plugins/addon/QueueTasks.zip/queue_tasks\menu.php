<?php
return [["name" => "功能设置", "url" => "QueueTasks://AdminIndex/setting", "custom" => 0]];

?>