<?php
namespace addons\queue_tasks\controller;

class AdminIndexController extends \app\admin\controller\PluginAdminBaseController
{
    public function setting()
    {
        $configurationsModel = \Think\Db::name("queue_tasks_config");
        $configData = $configurationsModel->find();
        $xufeiArray = explode(",", $configData["types"]);
        $fromtypeArray = explode(",", $configData["from_type"]);
        $isMismatch = false;
        $mismatchMessage = "恭喜您，授权成功";
        $this->assign("Title", "功能设置");
        $this->assign("Data", $configData);
        $this->assign("xufeiArray", $xufeiArray);
        $this->assign("fromtypeArray", $fromtypeArray);
        $this->assign("IsMismatch", $isMismatch);
        $this->assign("MismatchMessage", $mismatchMessage);
        return $this->fetch("/setting");
    }
    public function submit()
    {
        $data = $this->request->post();
        $apiid = isset($data["apiid"]) ? $data["apiid"] : NULL;
        $apikey = isset($data["apikey"]) ? $data["apikey"] : NULL;
        $zzemail = isset($data["zzemail"]) ? $data["zzemail"] : NULL;
        $zzqq = isset($data["zzqq"]) ? $data["zzqq"] : NULL;
        $mfauth = isset($data["mfauth"]) ? $data["mfauth"] : NULL;
        $smtp_is = isset($data["smtp_is"]) ? $data["smtp_is"] : NULL;
        $feishuurl = isset($data["feishuurl"]) ? $data["feishuurl"] : NULL;
        $dingurl = isset($data["dingurl"]) ? $data["dingurl"] : NULL;
        $wechaturl = isset($data["wechaturl"]) ? $data["wechaturl"] : NULL;
        $from_type = isset($data["fromtype"]) ? $data["fromtype"] : NULL;
        $types = isset($data["types"]) ? $data["types"] : NULL;
        $webname = isset($data["webname"]) ? $data["webname"] : NULL;
        $feishuswitch = isset($data["feishuswitch"]) ? $data["feishuswitch"] : NULL;
        $dingswitch = isset($data["dingswitch"]) ? $data["dingswitch"] : NULL;
        $wechatswitch = isset($data["wechatswitch"]) ? $data["wechatswitch"] : NULL;
        $tgswitch = isset($data["tgswitch"]) ? $data["tgswitch"] : NULL;
        $tgtoken = isset($data["tgtoken"]) ? $data["tgtoken"] : NULL;
        $tgchatid = isset($data["tgchatid"]) ? $data["tgchatid"] : NULL;
        $dbConfig = ["webname" => $webname, "weburl" => $_SERVER["HTTP_HOST"], "apiid" => $apiid, "apikey" => $apikey, "zzemail" => $zzemail, "zzqq" => $zzqq, "mfauth" => $mfauth, "feishuurl" => $feishuurl, "dingurl" => $dingurl, "wechaturl" => $wechaturl, "feishuswitch" => $feishuswitch, "dingswitch" => $dingswitch, "wechatswitch" => $wechatswitch, "tgswitch" => $tgswitch, "tgtoken" => $tgtoken, "tgchatid" => $tgchatid, "from_type" => $from_type, "types" => $types];
        $result = \Think\Db::name("queue_tasks_config")->where("id", 1)->find();
        if ($result) {
            $updateResult = \Think\Db::name("queue_tasks_config")->where("id", 1)->update($dbConfig);
            if ($updateResult !== false) {
                $response = ["code" => 200, "msg" => "设置已成功更新。"];
            } else {
                $response = ["code" => 500, "msg" => "更新设置时出错。"];
            }
        } else {
            $dbConfig["id"] = 1;
            $insertResult = \Think\Db::name("queue_tasks_config")->insert($dbConfig);
            if ($insertResult !== false) {
                $response = ["code" => 200, "msg" => "设置首次配置已成功。"];
            } else {
                $response = ["code" => 500, "msg" => "设置首次配置时出错。"];
            }
        }
        return json($response);
    }
}

?>