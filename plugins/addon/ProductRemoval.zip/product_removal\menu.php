<?php
return [["name" => "使用说明", "url" => "ProductRemoval://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "使用说明", "chinese_tw" => "使用說明", "english" => "Instructions"]]];

?>