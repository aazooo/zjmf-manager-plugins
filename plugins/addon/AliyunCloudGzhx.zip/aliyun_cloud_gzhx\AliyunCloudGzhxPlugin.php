<?php
namespace addons\aliyun_cloud_gzhx;

class AliyunCloudGzhxPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "AliyunCloudGzhx", "title" => "阿里云ECS", "description" => "阿里云ECS", "status" => 1, "author" => "GZHX Technology", "version" => "1.0.2", "module" => "addons", "not_install" => true];
    public function install()
    {
        $DbConfig = \Think\Db::getConfig();
        $CacheDbName = $DbConfig["prefix"] . "gzhx_cloud";
        $SettingDBName = $DbConfig["prefix"] . "gzhx_cloud_error";
        $tableList = \Think\Db::query("SELECT table_name FROM information_schema.TABLES WHERE TABLE_SCHEMA='" . $DbConfig["database"] . "'");
        $tableList = array_column($tableList, "table_name");
        if (!in_array($CacheDbName, $tableList)) {
            \Think\Db::query("CREATE TABLE `" . $CacheDbName . "`  (`id` int(11) NOT NULL AUTO_INCREMENT,`region` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`start_time` datetime(0) NULL DEFAULT NULL,`end_time` datetime(0) NULL DEFAULT NULL,`uid` int(11) NULL DEFAULT 0,`api_id` int(11) NULL DEFAULT 0,`config` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,`vid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`active` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '正常',`years` tinyint(3) NULL DEFAULT 1,`templete_info` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`task_id` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`last_update` datetime(0) NULL DEFAULT '2000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP(0),PRIMARY KEY (`id`) USING BTREE,INDEX `domain`(`domain`) USING BTREE,INDEX `api_id`(`api_id`) USING BTREE,INDEX `uid`(`uid`) USING BTREE,INDEX `vid`(`vid`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;");
        }
        if (!in_array($SettingDBName, $tableList)) {
            \Think\Db::query("CREATE TABLE `" . $SettingDBName . "`  (`id` int(11) NOT NULL AUTO_INCREMENT,`aid` int(11) NULL DEFAULT 0,`type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`msg` varchar(4000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`add_time` datetime(0) NULL DEFAULT NULL,`status` int(5) NULL DEFAULT 1,`domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`api_id` int(11) NULL DEFAULT 0,`op` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,PRIMARY KEY (`id`) USING BTREE,INDEX `domain`(`aid`) USING BTREE,INDEX `api_id`(`add_time`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;");
        }
        $manualDBName = $DbConfig["prefix"] . "gzhx_cloud_manual";
        if (!in_array($manualDBName, $tableList)) {
            \Think\Db::query("CREATE TABLE `" . $manualDBName . "`  (`id` int NOT NULL AUTO_INCREMENT,`aid` int NULL DEFAULT 0,`config` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,`status` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,`add_time` datetime NULL,PRIMARY KEY (`id`));");
        }
        $CacheDbName = $DbConfig["prefix"] . "gzhx_cloud_log";
        if (!in_array($CacheDbName, $tableList)) {
            \Think\Db::query("CREATE TABLE `" . $CacheDbName . "`  (`id` int(11) NOT NULL AUTO_INCREMENT,`log_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`aid` int(11) NULL DEFAULT 0,`type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`msg` varchar(4000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`add_time` datetime(0) NULL DEFAULT NULL,`status` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '1',`domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`api_id` int(11) NULL DEFAULT 0,`op` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,PRIMARY KEY (`id`) USING BTREE,INDEX `domain`(`aid`) USING BTREE,INDEX `api_id`(`add_time`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;");
        }
        $fieldList = \Think\Db::name("zjmf_finance_api")->getTableFields();
        if (!in_array("type", $fieldList)) {
            \Think\Db::query("ALTER TABLE `" . $DbConfig["prefix"] . "zjmf_finance_api` ADD COLUMN `type` varchar(25) NULL DEFAULT 'zjmf_api';");
        }
        if (!in_array("gzhx_user_id", $fieldList)) {
            \Think\Db::query("ALTER TABLE `" . $DbConfig["prefix"] . "zjmf_finance_api` ADD COLUMN `gzhx_user_id` varchar(25) NULL DEFAULT 'zjmf_api';");
        }
        $fieldList = \Think\Db::name("product_groups")->getTableFields();
        if (!in_array("zjfm_api_id", $fieldList)) {
            \Think\Db::query("ALTER TABLE `" . $DbConfig["prefix"] . "product_groups` ADD COLUMN `zjfm_api_id` int(11) NULL DEFAULT 0;");
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>