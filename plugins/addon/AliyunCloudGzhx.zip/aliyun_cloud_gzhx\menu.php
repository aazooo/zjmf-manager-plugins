<?php
return [["name" => "销售设置", "url" => "AliyunCloudGzhx://AdminIndex/index", "custom" => 0]];

?>