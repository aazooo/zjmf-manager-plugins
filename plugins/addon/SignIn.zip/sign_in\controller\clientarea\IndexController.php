<?php
namespace addons\sign_in\controller\clientarea;

class IndexController extends \app\home\controller\PluginHomeBaseController
{
    public function index()
    {
        $data["open"] = \think\Db::name("configuration")->where("setting", "sign_is")->value("value");
        $data["sign_type"] = \think\Db::name("configuration")->where("setting", "sign_type")->value("value");
        $data["sign_value"] = \think\Db::name("configuration")->where("setting", "sign_value")->value("value");
        $data["sign_gift"] = \think\Db::name("configuration")->where("setting", "sign_gift")->value("value");
        if ($data["sign_gift"] == 1) {
            $list = \think\Db::name("sign_gift")->select()->toArray();
            $this->assign("List", $list);
        }
        $this->assign("Data", $data);
        $this->assign("Title", "签到中心");
        if (empty($_POST)) {
            return $this->fetch("/index");
        }
        $sign_type = \think\Db::name("configuration")->where("setting", "sign_type")->value("value");
        $sign_value = \think\Db::name("configuration")->where("setting", "sign_value")->value("value");
        $sign = \think\Db::name("sign")->where("uid", $_POST["uid"])->find();
        $user = \think\Db::name("clients")->where("id", $_POST["uid"])->find();
        $point = $user["point"];
        $money = $user["credit"];
        if ($_POST["type"] == "point") {
            $user = \think\Db::name("clients")->where("id", $_POST["uid"])->find();
            $point = $user["point"];
            exit(json_encode(["code" => 200, "msg" => "您的当前积分为：" . $point]));
        }
        if ($_POST["type"] == "exchange") {
            $gift = \think\Db::name("sign_gift")->find($_POST["id"]);
            if ($point < $gift["point"]) {
                exit(json_encode(["code" => 100, "msg" => "积分不足" . $gift["point"]]));
            }
            if ($gift["type"] == "money") {
                \think\Db::name("clients")->where("id", $_POST["uid"])->update(["credit" => $money + $gift["value"], "point" => $point - $gift["point"]]);
                \think\Db::name("gift_log")->insert(["uid" => $_POST["uid"], "name" => $gift["name"], "time" => time(), "status" => 1]);
                exit(json_encode(["code" => 200, "msg" => "兑换成功，您获得：" . $gift["name"]]));
            }
            \think\Db::name("clients")->where("id", $_POST["uid"])->update(["point" => $point - $gift["point"]]);
            \think\Db::name("gift_log")->insert(["uid" => $_POST["uid"], "name" => $gift["name"], "time" => time(), "status" => 0]);
            exit(json_encode(["code" => 200, "msg" => "兑换成功，您获得：" . $gift["name"]]));
        }
        if (empty($sign)) {
            \think\Db::name("sign")->insert(["uid" => $_POST["uid"], "total" => 1, "last_time" => time()]);
            \think\Db::name("sign_log")->insert(["uid" => $_POST["uid"], "type" => $sign_type, "value" => $sign_value, "time" => time()]);
            if ($sign_type == "money") {
                \think\Db::name("clients")->where("id", $_POST["uid"])->update(["credit" => $money + $sign_value]);
                $type = "余额";
            } else {
                \think\Db::name("clients")->where("id", $_POST["uid"])->update(["point" => $point + $sign_value]);
                $type = "积分";
            }
            exit(json_encode(["code" => 200, "msg" => "签到成功！获得：" . $type . $sign_value]));
        }
        $last_time = date("Y-m-d", $sign["last_time"]);
        $now = date("Y-m-d", time());
        if ($last_time == $now) {
            exit(json_encode(["code" => 100, "msg" => "今天你已经签到过了！"]));
        }
        if ($sign_type == "money") {
            \think\Db::name("clients")->where("id", $_POST["uid"])->update(["credit" => $money + $sign_value]);
            $type = "余额";
        } else {
            \think\Db::name("clients")->where("id", $_POST["uid"])->update(["point" => $point + $sign_value]);
            $type = "积分";
        }
        \think\Db::name("sign")->where("uid", $_POST["uid"])->update(["last_time" => time()]);
        \think\Db::name("sign_log")->insert(["uid" => $_POST["uid"], "type" => $sign_type, "value" => $sign_value, "time" => time()]);
        exit(json_encode(["code" => 200, "msg" => "签到成功！获得：" . $type . $sign_value]));
    }
}

?>