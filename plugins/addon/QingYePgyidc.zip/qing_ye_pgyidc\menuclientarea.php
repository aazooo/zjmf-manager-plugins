<?php
return [["name" => "防火墙管理", "url" => "QingYePgyidc://Index/cc", "fa_icon" => "bx bxs-grid-alt"]];

?>