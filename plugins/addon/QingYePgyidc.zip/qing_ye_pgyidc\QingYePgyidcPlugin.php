<?php
namespace addons\qing_ye_pgyidc;

class QingYePgyidcPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "QingYePgyidc", "title" => "蒲公英防火墙", "description" => "宿迁高级代理,托管可以联系QQ3244920655", "status" => 1, "author" => "森屿云", "version" => "1.1.0", "module" => "addons"];
    public function install()
    {
        $sql = "CREATE TABLE IF NOT EXISTS `shd_qing_ye_pgyidc_ipzt` (\n    id int(11) NOT NULL AUTO_INCREMENT,\n    uid int(11) NOT NULL,\n    ip varchar(255) NOT NULL,\n    pgy_id int(11) NOT NULL,\n    add_time int(11) NOT NULL,\n    end_time int(11) NOT NULL,\n    PRIMARY KEY (id)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        \think\Db::execute($sql);
        return true;
    }
    public function uninstall()
    {
        $sql = "DROP TABLE IF EXISTS `shd_qing_ye_pgyidc_ipzt`";
        \think\Db::execute($sql);
        return true;
    }
    public function afterCron()
    {
        $res = \think\Db::name("plugin")->where("name", "QingYePgyidc")->find();
        $system = json_decode($res["config"], true);
        if (!empty($system["is_open"]) && $system["is_open"] == 1) {
            $common = new Common(0);
            $common->heartbeat($system["username"], $system["password"]);
        }
    }
    public function beforeCron()
    {
        $res = \think\Db::name("plugin")->where("name", "QingYePgyidc")->find();
        $system = json_decode($res["config"], true);
        if (!empty($system["is_open"]) && $system["is_open"] == 1) {
            $common = new Common(0);
            $common->heartbeat($system["username"], $system["password"]);
        }
    }
    public function templateAfterServicedetailSuspended($param)
    {
        $res = \think\Db::name("plugin")->where("name", "QingYePgyidc")->find();
        $system = json_decode($res["config"], true);
        if (!empty($system["is_open"]) && $system["is_open"] == 1) {
            $range = $system["range"];
            $hostid = intval($param["hostid"]);
            $tmp = \think\Db::name("host")->where("productid", "in", $range)->where("id", $hostid)->where("domainstatus", "Active")->find();
            if (empty($tmp)) {
                return "";
            }
            $urlCc = shd_addon_url("QingYePgyidc://Index/cc", ["hostId" => $hostid], true);
            $urlRid = shd_addon_url("QingYePgyidc://Index/rid", ["hostId" => $hostid], true);
            $urlLinKnUm = shd_addon_url("QingYePgyidc://Index/attack", ["hostId" => $hostid], true);
            $urlRateView = shd_addon_url("QingYePgyidc://Index/zt", ["hostId" => $hostid], true);
            $html = "\n        <button type=\"button\" class=\"btn btn-primary h-100 custom-button text-QingYePgyidc\" data-toggle=\"dropdown\" aria-expanded=\"false\">\n            防火墙管理\n        </button>\n        <div class=\"dropdown-menu\">\n            <a class=\"dropdown-item\" href=\"" . $urlCc . "\">IP CC策略</a>\n            <a class=\"dropdown-item\" href=\"" . $urlRid . "\">IP 释放</a>\n            <a class=\"dropdown-item\" href=\"" . $urlLinKnUm . "\">IP 攻击记录</a>\n            <a class=\"dropdown-item\" href=\"" . $urlRateView . "\">IP 直通</a>";
            $html .= "</div>";
            return $html;
        }
        return "";
    }
}

?>