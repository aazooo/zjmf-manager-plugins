<?php
namespace addons\qing_ye_pgyidc\controller;

class AdminIndexController extends \app\admin\controller\PluginAdminBaseController
{
    public function setting()
    {
        $product_groups = \think\Db::name("product_groups")->field("id,name")->select()->toArray();
        $products = \think\Db::name("products")->field("id,name,gid")->select()->toArray();
        $res_products = [];
        foreach ($products as $k => $v) {
            $res_products[$v["gid"]][] = $v;
        }
        $this->assign("productgroups", $product_groups);
        $this->assign("res_products", $res_products);
        $res = \think\Db::name("plugin")->where("name", "QingYePgyidc")->find();
        $system = json_decode($res["config"], true);
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $system["is_open"] = $param["is_open"] ?? 0;
            $system["username"] = $param["username"] ?? $system["username"];
            $system["password"] = $param["password"] ?? $system["password"];
            $system["range"] = $param["range"] ?: $system["range"];
            $dataArr["config"] = json_encode($system);
            if (!$res) {
                $this->assign("ErrorMsg", "插件安装错误");
            } else {
                \think\Db::name("plugin")->where("name", "QingYePgyidc")->update($dataArr);
                $this->assign("SuccessMsg", "配置成功");
            }
        }
        $this->assign("system", $system);
        $this->assign("selected", $system["range"]);
        return $this->fetch("/setting");
    }
}

?>