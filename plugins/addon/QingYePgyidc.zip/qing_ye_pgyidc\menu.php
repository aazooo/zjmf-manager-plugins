<?php
return [["name" => "设置", "url" => "QingYePgyidc://AdminIndex/setting", "custom" => 0]];

?>