<?php
return [["name" => "活动设置", "url" => "PayActivity://AdminIndex/activity", "custom" => 0], ["name" => "中奖记录", "url" => "PayActivity://AdminIndex/winningrecord", "custom" => 0]];

?>