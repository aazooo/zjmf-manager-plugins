<?php
return [["name" => "充值领红包", "url" => "PayActivity://Index/index", "fa_icon" => "bx bxs-grid-alt", "lang" => ["chinese" => "充值领红包", "chinese_tw" => "充值领红包", "english" => "Recharge red envelope"]]];

?>