<?php
/*
 *  自定义菜单
 */
return [
    [
        'name' => '域名列表',
        'url'  => 'Dominbygzhx://AdminIndex/index',
        'custom' => 0,
    ],
    [
        'name' => '手动域名处理',
        'url'  => 'Dominbygzhx://AdminIndex/manual',
        'custom' => 0,
    ],
    [
        'name' => '信息模版',
        'url'  => 'Dominbygzhx://AdminIndex/template_list',
        'custom' => 0,
    ],
    [
        'name' => '错误信息处理',
        'url'  => 'Dominbygzhx://AdminIndex/error_handling',
        'custom' => 0,
    ],
    [
        'name' => '注册设置',
        'url'  => 'Dominbygzhx://AdminIndex/suffix',
        'custom' => 0,
    ],
    [
        'name' => '系统日志',
        'url'  => 'Dominbygzhx://AdminIndex/operate_log',
        'custom' => 0,
    ],
    [
        'name' => '下游代理商',
        'url'  => 'Dominbygzhx://AdminIndex/api',
        'custom' => 0,
    ]
];