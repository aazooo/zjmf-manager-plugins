<?php
return [["name" => "余额提现", "url" => "", "fa_icon" => "bx bx-dollar-circle", "lang" => ["chinese" => "余额提现", "chinese_tw" => "餘額提現", "english" => "BalanceWithdrawal"], "child" => [["name" => "提现中心", "url" => "BalanceWithdrawal://Index/index", "fa_icon" => "bx bx-list-ul", "lang" => ["chinese" => "提现中心", "chinese_tw" => "提現中心", "english" => "Withdrawal Center"], "child" => []], ["name" => "提现管理", "url" => "BalanceWithdrawal://Index/indexlist", "fa_icon" => "bx bx-file", "lang" => ["chinese" => "提现管理", "chinese_tw" => "提現管理", "english" => "Withdrawal management"], "child" => []]]]];

?>