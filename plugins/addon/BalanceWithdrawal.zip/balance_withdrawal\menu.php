<?php
return [["name" => "功能设置", "url" => "BalanceWithdrawal://AdminIndex/setting", "custom" => 0, "lang" => ["chinese" => "功能设置", "chinese_tw" => "功能設置", "english" => "Function settings"]], ["name" => "提现列表", "url" => "BalanceWithdrawal://AdminIndex/withdrawallist", "custom" => 0, "lang" => ["chinese" => "提现列表", "chinese_tw" => "提現列表", "english" => "Withdrawal List"]]];

?>