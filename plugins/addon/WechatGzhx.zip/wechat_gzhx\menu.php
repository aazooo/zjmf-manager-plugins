<?php
/*
 *  自定义菜单
 */
return [
    [
        'name' => '基本设置',
        'url'  => 'WechatGzhx://AdminIndex/index',
        'custom' => 0,
    ],
    [
        'name' => '工单客服设置',
        'url'  => 'WechatGzhx://AdminIndex/manual',
        'custom' => 0,
    ],

    [
        'name' => '自有公众号设置',
        'url'  => 'WechatGzhx://AdminIndex/wechat',
        'custom' => 0,
    ], [
        'name' => '公众号菜单设置',
        'url'  => 'WechatGzhx://AdminIndex/carte',
        'custom' => 0,
    ],
    [
        'name' => '消息发送日志',
        'url'  => 'WechatGzhx://AdminIndex/log',
        'custom' => 0,
    ],
];