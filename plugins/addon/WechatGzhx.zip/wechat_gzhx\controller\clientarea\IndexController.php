<?php
namespace addons\wechat_gzhx\controller\clientarea;

use app\home\controller\PluginHomeBaseController;
use Think\Db;

class IndexController extends PluginHomeBaseController
{
    public $data,$theme="/ajax",$pluginName="wechat_gzhx";
    public function initialize()
    {


        parent::initialize();

        $this->assign('GzhxPluginPath',$this->pluginName);

        $this->data=$_POST;
    }
    public function success($arr){
        echo json_encode([
            'status'=>1,
            'encrypt'=>1,
            'info'=>$arr
        ]);die;
    }
    public function error($arr){
        echo json_encode([
            'status'=>0,
            'info'=>$arr
        ]);die;
    }
    public function fetchTemplete($p){
        $content=$this->fetch($this->theme.$p);
        if(!empty($this->theme)){
            preg_match("/<GZHXPAGEBOX>([\s\S]*?)<\/GZHXPAGEBOX>/isu",$content,$mth);
            return $mth[1];
        }else{
            return $content;
        }

    }
    public function curl($path,$data=[]){
        $data['backurl']=Db::name("configuration")->where("setting","=","domain")->value("value");
        $data['webname']=Db::name("configuration")->where("setting","=","company_name")->value("value");
        $data['uuid']=Db::name("configuration")->where("setting","=","system_license")->value("value");
        $iv = mb_substr(md5(mt_rand(1000000000000000,9999999999999999)),0,16);
        $ch = curl_init();
        $header = array(
            "HostAPI: idcsmart.com",
            "HostAPIIP: " . $_SERVER["SERVER_ADDR"],
            "HostAPISITE: " . $_SERVER["HTTP_HOST"],
            "Content-Type: application/json; charset=UTF-8",
            "X-Requested-With: XMLHttpRequest"
        );
        curl_setopt($ch, CURLOPT_URL, "https://connect.03s.cn/Wechat/{$path}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'data'=>base64_encode(openssl_encrypt(json_encode($data), 'aes-128-cbc', 'A89VB9PXBXJZ7834', true, $iv)),
            'iv'=>$iv
        ]) );
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        $result = curl_exec($ch);
        $info = curl_getinfo($ch);
        $curl_error = curl_error($ch);
        curl_close($ch);

        $data=json_decode($result,true);
        if(empty($data)){
            return [
                'status'=>0,
                'info'=>empty($curl_error)?'未知错误':$curl_error
            ];

        }

        return $data;
    }
 public function index(){

     $User=request()->uid;

     if(empty($User)){

         if(empty($User)){
             $this->assign('msg',"登录失效，请重新登录");
             return $this->fetch('/error');
         }
     }
     $Hook=[
         '工单'=>[
             'ticketAdminReply'=>'工单回复提醒',
             'ticketClose'=>'关闭工单提醒',
             'ticketStatusChange'=>'工单状态提醒',
         ],
         '产品'=>[
             'afterModuleChangePackage'=>'升降级成功',
             'afterModuleChangePackageFailed'=>'升降级失败',
             'afterModuleCrackPassword'=>'重置密码成功',
             'afterModuleCrackPasswordFailed'=>'重置密码失败',
             "afterModuleCreate"=>"开通成功",
             "afterModuleCreateFailed"=>"开通失败",
             "afterModuleSuspend"=>"暂停成功",
             "afterModuleSuspendFailed"=>"暂停失败",
             "afterModuleTerminate"=>"删除成功",
             "afterModuleTerminateFailed"=>"删除失败",
             "afterModuleUnsuspend"=>"解除暂停成功",
             "afterModuleUnsuspendFailed"=>"解除暂停失败",
             "afterModuleOn"=>"开机成功",
             "afterModuleOnFailed"=>"开机失败",
             "afterModuleOff"=>"关机成功",
             "afterModuleOffFailed"=>"模块关机失败",
             "afterModuleReboot"=>"重启成功",
             "afterModuleRebootFailed"=>"重启失败",
             "afterModuleHardOff"=>"硬关机成功",
             "afterModuleHardOffFailed"=>"硬关机失败",
             "afterModuleHardReboot"=>"硬重启成功",
             "afterModuleHardRebootFailed"=>"硬重启失败",
             "afterModuleReinstall"=>"重装系统成功",
             "afterModuleReinstallFailed"=>"重装系统失败",
             "afterModuleRescueSystem"=>"救援系统成功",
             "afterModuleRescueSystemFailed"=>"救援系统失败",
             "afterModuleSync"=>"拉取信息成功",
             "afterModuleSyncFailed"=>"拉取信息失败",
         ],
         "支付"=>[
             'shoppingCartSettle'=>'购物车结算',
         ]
     ];
  /*   foreach ($Hook['产品'] as $k=>$v){
         echo 'public function '.$k.'($param){'.PHP_EOL;
         echo 'if(!empty($param[\'hostid\'])){'.PHP_EOL;
         echo '$this->OrderSuccess(['.PHP_EOL;
         echo '\'id\'=>$param[\'hostid\'],'.PHP_EOL;
         echo '\'tag\'=>\''.$v.'\','.PHP_EOL;
         echo '\'hook\'=>\''.$k.'\','.PHP_EOL;
         echo ']);'.PHP_EOL;
         echo '};'.PHP_EOL;
         echo '}'.PHP_EOL.PHP_EOL;
     }
     die;*/
     if(empty($_GET['cache'])){
         $this->assign('Title',"微信助理");
         return $this->fetch($this->theme.'/ajax');
     }
     $wechatUid=Db::name("wechat_uid")->where("uid","=",$User)->find();

     if(!empty($this->data)){
         $action=$this->data['action'];
         if(empty($action)) $action="";

         switch ($action){

             case "save":{
                 if(empty($wechatUid)){
                     $this->error("请先关注公众号");
                 }
                 Db::name("wechat_uid")->where("uid","=",$User)->update([
                     'config'=>implode(",",$this->data['data'])
                 ]);
                 $this->success("OK");
                 break;
             }
             case "status":{
                 $result=$this->curl("status",$this->data);

                 if($result['status']==0){
                     $this->error($result['info']);
                 }
                 if(strval($result['info']['status'])=="2"){
                     if(empty($wechatUid)){
                         Db::name("wechat_uid")->insert([
                             'uid'=>$User,
                             'openid'=>$result['info']['raw']['openid'],
                             'nickname'=>$result['info']['raw']['nickname']
                         ]);
                     }else{
                         Db::name("wechat_uid")->where("uid","=",$User)->update([

                             'openid'=>$result['info']['raw']['openid'],
                             'nickname'=>$result['info']['raw']['nickname']
                         ]);
                     }

                     $this->success($result['info']);
                 }
                 $this->error($result['info']);


                 break;
             }
             case 'bind':{
                 $serverInfo=$this->curl("bind",[
                     'type'=>'user',
                     'uid'=>$User
                 ]);
                 if($serverInfo['status']!=1){
                     $this->error($serverInfo['info']);
                 }
                 $this->success($serverInfo['info']);
                 break;
             }



             default:{
                 $this->error("参数不存在");
                 break;
             }
         }

     }


     $this->assign('wechatUid',$wechatUid);

     $this->assign('wechatConfig',explode(",",$wechatUid['config']));

     $this->assign('Title','设置');

    $this->assign('HookList',$Hook);
     return $this->fetchTemplete('/index');
 }
 public function showError($str){
        die('<!DOCTYPE html><html lang="zh-CN"><head>    <meta charset="UTF-8">    <title>系统管理</title>    <meta name="renderer" content="webkit">    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">    <meta name="apple-mobile-web-app-status-bar-style" content="black">    <meta name="apple-mobile-web-app-capable" content="yes">    <meta name="format-detection" content="telephone=no"></head><body><h3>'.$str.'</h3></body>');
 }
 public function  getClientIP()
{
    global $ip;
    if (getenv("HTTP_CLIENT_IP"))
        $ip = getenv("HTTP_CLIENT_IP");
    else if (getenv("HTTP_X_FORWARDED_FOR"))
        $ip = getenv("HTTP_X_FORWARDED_FOR");
    else if (getenv("REMOTE_ADDR"))
        $ip = getenv("REMOTE_ADDR");
    else $ip = "Unknow";


    return $ip;
}
    public function localStorage(){

        $DbConfig=Db::getConfig();
        $admin_application=$DbConfig['admin_application'];
        $menuList=Db::name("auth_rule")->where("pid","=",0)->where("is_display","=",1)->select()->toArray();
        foreach ($menuList as $key=>$value){
            $SubMenuList=Db::name("auth_rule")->where("pid","=",$value["id"])->select()->toArray();
            if(!empty($SubMenuList)){
                foreach ($SubMenuList as $kk=>$vv){
                    $SubMenuList2=Db::name("auth_rule")->where("pid","=",$vv["id"])->select()->toArray()?:[];
                    if(!empty($SubMenuList2)){
                        $SubMenuList[$kk]['list']=$SubMenuList2;
                    }
                }
                $menuList[$key]['list']=$SubMenuList;
            }
        }
        $Admin=Db::name("user")->where("id","=",$_SESSION['think']['ADMIN_ID'])->find();
        $this->success([
            'data'=>[
                'userInfo'=>[
                    'user_login'=>$Admin['user_login'],
                    'user_nickname'=>$Admin['user_nickname'],
                ],
                'zjmf_lang_file_name'=>'zh',
                'showAside'=>true,
                'limit'=>50,
                'token'=>'success',
                'zjmf_lang_type'=>'CN',
                'menuList'=>$menuList
            ],
            'configLang'=>"/{$admin_application}/community/configLang?request_time=".time()."&languagesys=CN"
        ]);
    }
    public function member(){
        $data=unserialize(openssl_decrypt(hex2bin($_GET['id']), 'aes-128-cbc', 'A89VB9PXBXJZ7834', true, 'A09VB9PXBXJZ7834'));
        if(empty($data)){
            $this->showError("参数错误");
        }

        $configuration= Db::name("configuration")->where("setting","=","gzhx_wechat_{$data['type']}")->find();
        $bind=unserialize(base64_decode($configuration['value']));
        if($data['openid']=="member"){
            $bind["member"]['user_id']=$configuration['value'];
        }else{
            if(!array_key_exists($data['openid'],$bind)){
                $this->showError("未找到客服");
            }
        }

        if(empty($bind[$data['openid']]['user_id'])){
            $this->showError("当前客服未绑定帐号");
        }
        $DbConfig=Db::getConfig();
        $admin_application=$DbConfig['admin_application'];
         $Admin=Db::name("user")->where("user_login","=",$bind[$data['openid']]['user_id'])->find();
           $ip=$this->getClientIP();
           if(empty($Admin)){
               $this->showError("当前客服未绑定帐号");
           }


        $token=cmf_generate_user_token($Admin['id'],'web');
        sessionInit();
        session_start();
        session("ADMIN_ID",$Admin['id']);
        session("name",$Admin['user_login']);
        session("admin_login_info",md5($ip));
        session("token",$token);
        header("location:/plugins/addons/wechat_gzhx/template/local_storage.html?uri=".urlencode("/{$admin_application}/{$data['url']}"));die;
       // header("location:/{$admin_application}/{$data['url']}");die;
        die;
    }
    public function Touser(){
        if(!file_exists(CMF_DATA."key.key")){
            file_put_contents(CMF_DATA."key.key",time());
        }
        $key=file_get_contents(CMF_DATA."key.key");
        $data=unserialize(openssl_decrypt(hex2bin($_GET['id']), 'aes-128-cbc', 'A79VB9PXBXJZ7834', true, mb_substr(md5($key),8,16)));
        if(empty($data)){
            $this->showError("参数错误");
        }
        $User=Db::name("clients")->where('id','=',$data['uid'])->find();
        if(empty($User)){
            $this->showError('获取用户失败');
        }
        $jwt=createJwt($User);
        userSetCookie($jwt);
        header("location:{$data['url']}");die;
    }
    public function Toclient(){


        $User=Db::name("clients")->where('id','=',$_GET['uuid'])->find();
        if(empty($User)){
            $this->showError('获取用户失败');
        }
        $Uid=Db::name("wechat_uid")->where('uid','=',$_GET['uuid'])->find();
        if(empty($Uid)){
            $this->showError('获取用户失败');
        }

        $data=unserialize(openssl_decrypt(hex2bin($_GET['id']), 'aes-128-cbc', 'A89VB9PXBXJZ7834', true, mb_substr(md5($Uid['openid']),8,16)));
        if(empty($data)){
            $this->showError("参数错误");
        }

        $jwt=createJwt($User);
        userSetCookie($jwt);
        header("location:{$data['url']}");die;
    }
    public function getUrl()
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $url = $protocol . $_SERVER['HTTP_HOST'];
        return $url;
    }
    public function Wechat(){
        if(!empty($_GET['uuid'])){
            $authorization_data=$this->curl("location_data", [
                'id'=>$_GET['uuid']
            ]);
            if($authorization_data['status']!=1){
                $this->showError($authorization_data['info']);
            }
            $config=unserialize($authorization_data['info']['config']);
            $Uri=openssl_decrypt(hex2bin($config['query']['token']), 'aes-128-cbc', 'A89VB9PXBXJZ7834', true, 'A89VB9PXBXJZ7834');

            $User=Db::name('wechat_uid')->where('openid',"=",$authorization_data['info']['openid'])->select()->toArray();
            if(empty($User)||count($User)<1){
                $this->showError("当前帐号未绑定帐号");
            }
            if(count($User)==1){
                $UserData=Db::name("clients")->where('id','=',$User[0]['uid'])->find();

                if(empty($UserData)){
                    $this->showError('获取用户失败');
                }

                $jwt=createJwt($UserData);
                userSetCookie($jwt);
                header("location:{$Uri}");die;
            }
            if(!file_exists(CMF_DATA."key.key")){
                file_put_contents(CMF_DATA."key.key",time());
            }
            $vkey=file_get_contents(CMF_DATA."key.key");

            $UserList=[];
            foreach ($User as $key=>$item){
                $UserData=Db::name("clients")->where('id','=',$item['uid'])->find();

                if(!empty($UserData)){
                    $idInfo="/addons?_plugin=wechat_gzhx&_controller=index&_action=touser&id=".bin2hex(openssl_encrypt(serialize([
                            'uid'=>$item['uid'],
                            'url'=>$Uri
                        ]), 'aes-128-cbc', 'A79VB9PXBXJZ7834', true, mb_substr(md5($vkey),8,16)));
                    $UserList[]="<a href=\"{$idInfo}\" class=\"layui-btn\">{$UserData['username']}</a>";
                }

            }
            echo '<!DOCTYPE html><html lang="en"><head>    <meta charset="UTF-8">    <title>选择帐号</title>  <meta name="renderer" content="webkit">  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">  <meta name="apple-mobile-web-app-status-bar-style" content="black">  <meta name="apple-mobile-web-app-capable" content="yes">  <meta name="format-detection" content="telephone=no">    <style>      html,body{        height: 100%;        overflow: hidden;      }      body{        display: flex;        justify-content: center;        align-items: center;        flex-direction: column;      }      .layui-btn, .layui-edge, .layui-inline, img {        vertical-align: middle;      }      .layui-btn, .layui-disabled, .layui-icon, .layui-unselect {        -moz-user-select: none;        -webkit-user-select: none;        -ms-user-select: none;      }      .layui-btn, .layui-btn-group, .layui-edge {        display: inline-block;      }      .layui-btn, .layui-input, .layui-select, .layui-textarea, .layui-upload-button {        outline: 0;        -webkit-appearance: none;        transition: all .3s;        -webkit-transition: all .3s;        box-sizing: border-box;      }      .layui-btn {        height: 38px;        line-height: 38px;        border: 1px solid transparent;        padding: 0 18px;        background-color: #009688;        color: #fff;        white-space: nowrap;        text-align: center;        font-size: 14px;        border-radius: 2px;        cursor: pointer;        margin: 10px auto;        width: 80%;      }      .layui-btn-primary {        border-color: #d2d2d2;        background: 0 0;        color: #666;      }    </style></head><body><h3>请选择要登录的帐号</h3>'.implode("",$UserList).'</body></html>';
            die;

        }
        $authorization=$this->curl("location_uri",[

            'uri'=>[
                'query'=>$_GET,
                'url'=>$this->getUrl()
            ]
        ]);
        if($authorization['status']!=1){
            $this->showError($authorization['info']);
        }
        header("location:{$authorization['info']}");die;
    }
}