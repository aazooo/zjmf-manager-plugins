<?php
return [["name" => "功能设置", "url" => "PointsOffset://AdminIndex/setting", "custom" => 0, "lang" => ["chinese" => "功能设置", "chinese_tw" => "功能設置", "english" => "Setting"]], ["name" => "订单记录", "url" => "PointsOffset://AdminIndex/records", "custom" => 0, "lang" => ["chinese" => "订单记录", "chinese_tw" => "訂單記錄", "english" => "Records"]]];

?>