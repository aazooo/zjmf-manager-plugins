<?php
return [["name" => "积分抵现计划", "url" => "PointsOffset://Index/index", "fa_icon" => "bx bx-disc", "lang" => ["chinese" => "积分抵现计划", "chinese_tw" => "積分抵現抵扣", "english" => "Points offset plan"]]];

?>