<?php
namespace addons\bill_notifyrobot\controller;

class AdminIndexController extends \app\admin\controller\PluginAdminBaseController
{
    public function setting()
    {
        $configurationsModel = \Think\Db::name("bill_notifyrobot");
        $configData = $configurationsModel->find();
        $authorize = \Think\Db::name("bill_notifyrobot")->where("id", 1)->value("mfauth");
        $system_license = \Think\Db::name("configuration")->where("setting", "system_license")->value("value");
        $isMismatch = false;
        $mismatchMessage = "恭喜您，授权成功";
        $this->assign("Title", "功能设置");
        $this->assign("Data", $configData);
        $this->assign("IsMismatch", $isMismatch);
        $this->assign("MismatchMessage", $mismatchMessage);
        return $this->fetch("/setting");
    }
    public function submit()
    {
        $data = $this->request->post();
        $zzemail = isset($data["zzemail"]) ? $data["zzemail"] : NULL;
        $zzqq = isset($data["zzqq"]) ? $data["zzqq"] : NULL;
        $mfauth = isset($data["mfauth"]) ? $data["mfauth"] : NULL;
        $smtp_is = isset($data["smtp_is"]) ? $data["smtp_is"] : NULL;
        $feishuurl = isset($data["feishuurl"]) ? $data["feishuurl"] : NULL;
        $dingurl = isset($data["dingurl"]) ? $data["dingurl"] : NULL;
        $wechaturl = isset($data["wechaturl"]) ? $data["wechaturl"] : NULL;
        $webname = isset($data["webname"]) ? $data["webname"] : NULL;
        $chongzhi = isset($data["chongzhi"]) ? $data["chongzhi"] : NULL;
        $chanpin = isset($data["chanpin"]) ? $data["chanpin"] : NULL;
        $xufei = isset($data["xufei"]) ? $data["xufei"] : NULL;
        $feishuswitch = isset($data["feishuswitch"]) ? $data["feishuswitch"] : NULL;
        $dingswitch = isset($data["dingswitch"]) ? $data["dingswitch"] : NULL;
        $wechatswitch = isset($data["wechatswitch"]) ? $data["wechatswitch"] : NULL;
        $tgswitch = isset($data["tgswitch"]) ? $data["tgswitch"] : NULL;
        $tgtoken = isset($data["tgtoken"]) ? $data["tgtoken"] : NULL;
        $tgchatid = isset($data["tgchatid"]) ? $data["tgchatid"] : NULL;
        $amount = isset($data["amount"]) ? $data["amount"] : NULL;
        if (empty($data["amount"])) {
            $response = ["code" => 400, "msg" => "请正确输入账单起始通知金额。"];
            return json($response);
        }
        $dbConfig = ["webname" => $webname, "zzemail" => $zzemail, "zzqq" => $zzqq, "mfauth" => $mfauth, "feishuurl" => $feishuurl, "dingurl" => $dingurl, "wechaturl" => $wechaturl, "chongzhi" => $chongzhi, "chanpin" => $chanpin, "xufei" => $xufei, "feishuswitch" => $feishuswitch, "dingswitch" => $dingswitch, "wechatswitch" => $wechatswitch, "tgswitch" => $tgswitch, "tgtoken" => $tgtoken, "tgchatid" => $tgchatid, "amount" => $amount, "weburl" => $_SERVER["HTTP_HOST"]];
        $result = \Think\Db::name("bill_notifyrobot")->where("id", 1)->find();
        if ($result) {
            $updateResult = \Think\Db::name("bill_notifyrobot")->where("id", 1)->update($dbConfig);
            if ($updateResult !== false) {
                $response = ["code" => 200, "msg" => "设置已成功更新。"];
            } else {
                $response = ["code" => 500, "msg" => "更新设置时出错。"];
            }
        } else {
            $dbConfig["id"] = 1;
            $insertResult = \Think\Db::name("bill_notifyrobot")->insert($dbConfig);
            if ($insertResult !== false) {
                $response = ["code" => 200, "msg" => "设置首次配置已成功。"];
            } else {
                $response = ["code" => 500, "msg" => "设置首次配置时出错。"];
            }
        }
        return json($response);
    }
}

?>