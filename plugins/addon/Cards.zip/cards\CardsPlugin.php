<?php
namespace addons\cards;

class CardsPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "Cards", "title" => "卡密充值插件", "description" => "此插件可实现用户使用卡密充余额，后台查看卡密列表，并对卡密进行创建、删除等操作", "status" => 1, "author" => "缔梦", "version" => "1.1.1", "module" => "addons", "lang" => ["chinese" => "卡密充值插件", "chinese_tw" => "卡密充值插件", "english" => "Card encryption recharge plug-in"]];
    public function install()
    {
        $sql = ["DROP TABLE IF EXISTS `shd_cards`", "CREATE TABLE `shd_cards` (  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,  `card` text NOT NULL DEFAULT '' COMMENT '独立ip地址',  `money` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '分配的ip地址',  `end_time` int(11) DEFAULT NULL COMMENT '使用时间',  `uid` int(11) DEFAULT NULL COMMENT '使用者',  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8", "INSERT INTO shd_configuration (setting, value) VALUES ('is_card','1');"];
        foreach ($sql as $v) {
            \think\Db::query($v);
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
    public function clientLogin()
    {
    }
}

?>