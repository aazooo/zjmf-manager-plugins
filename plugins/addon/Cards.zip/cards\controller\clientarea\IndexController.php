<?php
namespace addons\cards\controller\clientarea;

class IndexController extends \app\home\controller\PluginHomeBaseController
{
    public function index()
    {
        $data["open"] = \think\Db::name("configuration")->where("setting", "is_card")->value("value");
        $this->assign("Data", $data);
        $this->assign("Title", "卡密充值");
        if (empty($_POST)) {
            return $this->fetch("/index");
        }
        $user = \think\Db::name("clients")->find($_POST["uid"]);
        $card = \think\Db::name("cards")->where("card", $_POST["card"])->find();
        if (empty($card)) {
            exit(json_encode(["code" => 100, "msg" => "卡密不存在！"]));
        }
        if (empty($card["end_time"])) {
            $money = $user["credit"] + $card["money"];
            \think\Db::name("clients")->where("id", $_POST["uid"])->update(["credit" => $money]);
            \think\Db::name("cards")->where("card", $_POST["card"])->update(["uid" => $_POST["uid"], "end_time" => time()]);
            exit(json_encode(["code" => 200, "msg" => "充值成功，金额：" . $card["money"]]));
        }
        exit(json_encode(["code" => 100, "msg" => "卡密已被使用！"]));
    }
}

?>