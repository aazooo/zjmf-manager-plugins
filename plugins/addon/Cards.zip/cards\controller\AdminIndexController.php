<?php
namespace addons\cards\controller;

class AdminIndexController extends \app\admin\controller\PluginAdminBaseController
{
    private $_config = [];
    private $lang;
    public function initialize()
    {
        parent::initialize();
        if (file_exists(dirname(__DIR__) . "/config/config.php")) {
            $con = (require dirname(__DIR__) . "/config/config.php");
        } else {
            $con = [];
        }
        $this->_config = array_merge($con, $this->getPlugin()->getConfig());
        $lang = request()->languagesys;
        if (empty($lang)) {
            $lang = configuration("language") ? configuration("language") : config("default_lang");
        }
        if ($lang == "CN") {
            $lang = "chinese";
        } else {
            if ($lang == "US") {
                $lang = "english";
            } else {
                if ($lang == "HK") {
                    $lang = "chinese_tw";
                }
            }
        }
        $this->lang = $lang;
    }
    public function submit()
    {
        $data = $_POST;
        foreach ($data as $setting => $value) {
            \think\Db::name("clients_config")->where("setting", $setting)->update(["value" => $value]);
        }
        exit(json_encode(["code" => 200, "msg" => "修改成功"]));
    }
    public function config()
    {
        $data["is"] = \think\Db::name("configuration")->where("setting", "is_card")->value("value");
        $this->assign("Data", $data);
        $this->assign("Title", "卡密设置");
        return $this->fetch("/config");
    }
    public function list()
    {
        $list = \think\Db::name("cards")->select()->toArray();
        foreach ($list as $key => $value) {
            $user = \think\Db::name("clients")->find($list["uid"]);
            $list[$key]["user"] = $user["username"];
        }
        $this->assign("Title", "卡密列表");
        $this->assign("List", $list);
        return $this->fetch("/list");
    }
    public function create()
    {
        $this->assign("Title", "卡密生成");
        return $this->fetch("/create");
    }
    public function add()
    {
        $data = $_POST;
        if (empty($data["num"])) {
            exit(json_encode(["code" => 100, "msg" => "卡密数量不能为空！"]));
        }
        if (empty($data["money"])) {
            exit(json_encode(["code" => 100, "msg" => "卡密金额不能为空！"]));
        }
        for ($i = 1; $i <= $data["num"]; $i++) {
            $card = ["card" => md5(mt_rand()), "money" => $data["money"], "create_time" => time()];
            \think\Db::name("cards")->insert($card);
        }
        exit(json_encode(["code" => 200, "msg" => "卡密生成成功！"]));
    }
    public function pass()
    {
        $id = $_POST["id"];
        $data = \think\Db::name("cards")->where("id", $id)->update(["end_time" => "1"]);
        if ($data) {
            exit(json_encode(["code" => 200, "msg" => "修改卡密状态成功"]));
        }
        exit(json_encode(["code" => 100, "msg" => "修改卡密状态失败！"]));
    }
    public function delete()
    {
        $id = $_POST["id"];
        $data = \think\Db::name("cards")->where("id", $id)->delete();
        if ($data) {
            exit(json_encode(["code" => 200, "msg" => "卡密删除成功"]));
        }
        exit(json_encode(["code" => 100, "msg" => "卡密删除失败！"]));
    }
    public function export()
    {
        $data = \think\Db::name("cards")->where("end_time", NULL)->select()->toArray();
        foreach ($data as $item) {
            $content .= $item["card"] . " -- 面额：" . $item["money"] . "\r\n";
        }
        Header("Content-type:application/octet-stream");
        Header("Accept-Ranges:bytes");
        header("Content-Disposition:attachment;filename=test.txt");
        header("Expires:0");
        header("Cache-Control:must-revalidate,post-check=0,pre-check=0 ");
        header("Pragma:public");
        echo $content;
    }
}

?>