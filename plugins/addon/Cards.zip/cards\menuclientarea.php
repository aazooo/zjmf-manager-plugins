<?php
return [["name" => "卡密充值", "url" => "Cards://Index/index", "fa_icon" => "bx bx-dollar-circle", "lang" => ["chinese" => "卡密充值", "chinese_tw" => "卡密充值", "english" => "Card recharge"], "child" => []]];

?>