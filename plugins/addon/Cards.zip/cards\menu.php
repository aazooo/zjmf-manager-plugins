<?php
return [["name" => "卡密设置", "url" => "Cards://AdminIndex/config", "custom" => 0, "lang" => ["chinese" => "卡密设置", "chinese_tw" => "卡密設置", "english" => "Card secret setting"]], ["name" => "卡密生成", "url" => "Cards://AdminIndex/create", "custom" => 0, "lang" => ["chinese" => "卡密生成", "chinese_tw" => "卡密生成", "english" => "Card secret create"]], ["name" => "卡密列表", "url" => "Cards://AdminIndex/list", "custom" => 0, "lang" => ["chinese" => "卡密列表", "chinese_tw" => "卡密列表", "english" => "Card secret list"]]];

?>