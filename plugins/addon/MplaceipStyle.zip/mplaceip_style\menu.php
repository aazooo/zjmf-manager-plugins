<?php
return [["name" => "设置", "url" => "MplaceipStyle://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "设置", "english" => "set"]], ["name" => "配置", "url" => "MplaceipStyle://AdminIndex/dispose", "custom" => 0, "lang" => ["chinese" => "配置", "english" => "dispose"]], ["name" => "管理", "url" => "MplaceipStyle://AdminIndex/list", "custom" => 0, "lang" => ["chinese" => "管理", "english" => "list"]]];

?>