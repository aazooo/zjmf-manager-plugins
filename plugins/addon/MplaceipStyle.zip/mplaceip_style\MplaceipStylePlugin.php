<?php
namespace addons\mplaceip_style;

class MplaceipStylePlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "MplaceipStyle", "title" => "IP修改", "description" => "自助更换IP", "status" => 1, "author" => "陌斯/IUWUO", "version" => "1.0", "module" => "addons", "lang" => ["chinese" => "自助更换IP", "english" => "place IP"]];
    public function install()
    {
        mkdir("mplaceip_data");
        mkdir("mplaceip_data/data");
        $mplaceip_body = "\n<?php\nreturn array(\n\"admin\"=>hex2bin(\"61646d696e73\"),\n\"user\"=>hex2bin(\"7573657273\"),\n\"pass\"=>hex2bin(\"7061737373\"),\n\"number\"=>hex2bin(\"3130\"),\n);\n";
        file_put_contents("mplaceip_data/config.php", $mplaceip_body);
        if (is_dir("mplaceip_data/data") && is_dir("mplaceip_data") && is_file("mplaceip_data/config.php")) {
            return true;
        }
        return false;
    }
    public function uninstall()
    {
        @delDir("mplaceip_data");
        if (!is_dir("mplaceip_data")) {
            return true;
        }
        return false;
    }
    public function clientLogin()
    {
    }
}
function delDir($directory)
{
    if (file_exists($directory) && ($dir_handle = @opendir($directory))) {
        while ($filename = readdir($dir_handle)) {
            if ($filename != "." && $filename != "..") {
                $subFile = $directory . "/" . $filename;
                if (is_dir($subFile)) {
                    delDir($subFile);
                }
                if (is_file($subFile)) {
                    unlink($subFile);
                }
            }
        }
        closedir($dir_handle);
        rmdir($directory);
    }
}

?>