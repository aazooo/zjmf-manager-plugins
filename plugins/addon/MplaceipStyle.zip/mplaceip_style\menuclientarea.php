<?php
return [["name" => "自助更换IP", "url" => "", "fa_icon" => "bx bxs-grid-alt", "lang" => ["chinese" => "自助更换IP", "english" => "place IP"], "child" => [["name" => "自助更换IP", "url" => "MplaceipStyle://Index/index", "fa_icon" => "", "lang" => ["chinese" => "自助更换IP", "english" => "place IP"], "child" => []]]]];

?>