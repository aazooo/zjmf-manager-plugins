<?php
return [["name" => "机器人通知设置", "url" => "RobotNot://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "机器人通知设置", "chinese_tw" => "机器人通知设置", "english" => "机器人通知设置"]]];

?>