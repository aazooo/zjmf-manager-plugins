<?php
namespace addons\activity_hongbao;

class ActivityHongbaoPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "ActivityHongbao", "title" => "活动红包", "description" => "支持前台客户领取红包", "status" => 1, "author" => "<a href=\"https://www.bear-studio.net\">BearStudio Team</a>", "version" => "1.0", "module" => "addons"];
    public function install()
    {
        $sql = ["DROP TABLE IF EXISTS `shd_activity_hongbao`", "CREATE TABLE `shd_activity_hongbao`  (  `id` int(10) NOT NULL AUTO_INCREMENT,  `uid` int(200) NOT NULL COMMENT '用户id',  `money` varchar(500) NOT NULL DEFAULT '' COMMENT '金额',  `date` int(10) NOT NULL DEFAULT 0 COMMENT '时间',  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"];
        foreach ($sql as $v) {
            \think\Db::execute($v);
        }
        return true;
    }
    public function uninstall()
    {
        $sql = "DROP TABLE IF EXISTS `shd_activity_hongbao`";
        \think\Db::execute($sql);
        return true;
    }
}

?>