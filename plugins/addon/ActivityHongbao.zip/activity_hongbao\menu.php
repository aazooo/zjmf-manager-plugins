<?php
return [["name" => "基础配置", "url" => "ActivityHongbao://AdminIndex/setting", "custom" => 0], ["name" => "领取列表", "url" => "ActivityHongbao://AdminIndex/index", "custom" => 0]];

?>