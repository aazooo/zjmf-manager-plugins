<?php
return [["name" => "领取红包", "url" => "ActivityHongbao://Index/hongbao", "fa_icon" => "bx bx-crown", "lang" => ["chinese" => "领取红包", "chinese_tw" => "领取红包", "english" => "Redbag"]]];

?>