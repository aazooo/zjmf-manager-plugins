<?php
namespace addons\activity_hongbao\model;

class ActivityHongbaoModel
{
    public static function getList($param)
    {
        return ["status" => 200];
    }
}

?>