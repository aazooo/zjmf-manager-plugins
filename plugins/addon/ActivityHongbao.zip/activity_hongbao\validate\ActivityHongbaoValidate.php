<?php
namespace addons\activity_hongbao\validate;

class ActivityHongbaoValidate extends \think\Validate
{
    protected $rule = ["is_open" => "require|int", "redbagnumber" => "require|int", "tips" => "require|int"];
    protected $message = ["is_open" => "不能为空|只支持数字", "redbagnumber" => "不能为空|只支持数字", "tips" => "不能为空|请填写关闭活动时的提示语"];
}

?>