<?php
namespace addons\activity_hongbao\controller\clientarea;

class IndexController extends \app\home\controller\PluginHomeBaseController
{
    public function hongbao(\think\Request $request)
    {
        $param = $request->param();
        $res = \think\Db::name("plugin")->where("name", "ActivityHongbao")->find();
        $system = json_decode($res["config"], true);
        $res_data = $this->data_pagedata($request, $param);
        $data["page_data"] = $res_data["page_data"];
        $data["our"] = $system;
        $number = $system["redbagnumber"];
        $number = explode("-", $number);
        $data["isopen"] = $system["is_open"];
        $data["tips"] = $system["tips"];
        if ($data["isopen"] == 1) {
            $verify = \think\Db::name("activity_hongbao")->where("uid", $param["uid"])->find();
            if ($verify) {
                $data["already"] = 1;
                $alreadys = \think\Db::name("activity_hongbao")->where("uid", $param["uid"])->find();
                $alreadyss = json_decode($alreadys["money"], true);
                $data["alreadyss"] = $alreadyss;
                $this->assign("Title", "领红包");
                return $this->fetch("/hongbao", $data);
            }
            if (!$verify) {
                $data["already"] = 0;
                $data["randmoneyd"] = mt_rand($number[0], $number[1]);
                $data["status"] = "已登录";
                $redbag = ["uid" => $param["uid"], "money" => $data["randmoneyd"], "date" => time()];
                \think\Db::name("activity_hongbao")->insert($redbag);
                $credit = \think\Db::name("clients")->where("id", $param["uid"])->find();
                $credits = $credit["credit"];
                $creditgetnumber = $credit["credit"] + $data["randmoneyd"];
                \think\Db::name("clients")->where(["id" => $param["uid"]])->update(["credit" => $creditgetnumber]);
                $this->assign("Title", "领红包");
                return $this->fetch("/hongbao", $data);
            }
            $data["user_now"] = $param["uid"];
        } else {
            $this->assign("Title", "领红包");
            return $this->fetch("/hongbao", $data);
        }
    }
    private function data_pagedata(\think\Request $request, $param)
    {
        $this->page_data_register($request);
        $res_product_divert = \addons\activity_hongbao\model\ActivityHongbaoModel::getList($param);
        $res_data = $res_product_divert["data"];
        $res_count = $res_product_divert["count"];
        $page_data = $this->page_data_rendering($request, $res_data, $res_count);
        return ["status" => 200, "data" => $res_product_divert["data"], "page_data" => $page_data];
    }
    private function page_data_register(\think\Request $request)
    {
        $param = $request->param();
        $page = 1 <= $param["page"] ? intval($param["page"]) : 1;
        $limit = 1 <= $param["limit"] ? intval($param["limit"]) : 20;
        $orderby = strval($param["orderby"]) ? strval($param["orderby"]) : "create_time";
        $sort = $param["sort"] ?? "DESC";
        $request->page = $page;
        $request->limit = $limit;
        $request->order = $orderby;
        $request->sort = $sort;
        return true;
    }
    private function page_data_rendering(\think\Request $request, $data, $count)
    {
        $param = $request->param();
        $page = 1 <= $param["page"] ? intval($param["page"]) : 1;
        $limit = 1 <= $param["limit"] ? intval($param["limit"]) : 20;
        $page_data["Pages"] = $this->ajaxPages($data, $limit, $page, $count);
        $page_data["Limit"] = $limit;
        $page_data["Count"] = $count;
        return $page_data;
    }
}

?>