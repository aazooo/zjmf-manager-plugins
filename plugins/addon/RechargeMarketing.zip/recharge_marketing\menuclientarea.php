<?php
return [["name" => "充值活动", "url" => "RechargeMarketing://Index/activitylist", "fa_icon" => "bx bx-yen", "lang" => ["chinese" => "充值活动", "chinese_tw" => "充值活動", "english" => "Recharge Marketing"]]];

?>