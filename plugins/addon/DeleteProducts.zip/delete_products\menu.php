<?php
return [["name" => "删除商品", "url" => "DeleteProducts://AdminIndex/index", "custom" => 0]];

?>