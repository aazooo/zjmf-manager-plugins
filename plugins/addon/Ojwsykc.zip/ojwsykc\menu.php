<?php
return [["name" => "使用说明", "url" => "Ojwsykc://AdminIndex/addhelp", "custom" => 0, "lang" => ["chinese" => "使用说明", "chinese_tw" => "使用說明", "english" => "instructions"]]];

?>