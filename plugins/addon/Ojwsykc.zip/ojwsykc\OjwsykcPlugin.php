<?php
namespace addons\ojwsykc;

class OjwsykcPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "Ojwsykc", "title" => "OJW同步上游库存插件", "description" => "OJW同步上游库存插件", "status" => 1, "author" => "OJW", "version" => "2.5.0", "module" => "addons"];
    public function install()
    {
        return true;
    }
    public function uninstall()
    {
        return true;
    }
    public function afterCron()
    {
        $DbConfig = \think\Db::getConfig();
        $products = "products";
        $protuct = \think\Db::name($products)->where("upstream_product_shopping_url", "not null")->select();
        foreach ($protuct as $k => $v) {
            if ($v["upstream_stock_control"] == 1) {
                \think\Db::name($products)->where("id", $v["id"])->update(["stock_control" => 1, "qty" => $v["upstream_qty"]]);
            }
        }
    }
}

?>