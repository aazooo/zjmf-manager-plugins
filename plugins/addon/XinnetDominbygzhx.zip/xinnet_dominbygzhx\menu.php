<?php
return [["name" => "销售设置", "url" => "XinnetDominbygzhx://AdminIndex/index", "custom" => 0]];

?>