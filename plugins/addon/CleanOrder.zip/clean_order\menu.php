<?php
return [["name" => "手动执行", "url" => "CleanOrder://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "手动执行", "chinese_tw" => "手動執行", "english" => "Manual Execution"]]];

?>