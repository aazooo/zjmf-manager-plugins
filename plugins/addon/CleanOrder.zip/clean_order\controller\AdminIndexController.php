<?php
namespace addons\clean_order\controller;

class AdminIndexController extends \app\admin\controller\PluginAdminBaseController
{
    private $_config = [];
    private $lang;
    public function setting()
    {
        \think\Db::name("run_maping")->where("from_type", 400)->where("active_type", "in", [2])->where("description", "like", "%只有激活和暂停状态才能暂停%")->where("status", 0)->update(["active_type" => 4]);
        $rowsToUpdate = \think\Db::name("run_maping")->where("from_type", 400)->where("active_type", "in", [4])->where("status", 0)->field("id, description")->select();
        foreach ($rowsToUpdate as $row) {
            $newDescription = $row["description"];
            if (strpos($newDescription, "【手动任务已更新为删除】: ") !== 0) {
                $newDescription = "【手动任务已更新为删除】: " . $newDescription;
                \think\Db::name("run_maping")->where("id", $row["id"])->update(["description" => $newDescription]);
            }
        }
        $affectedRows = \think\Db::name("run_maping")->where("from_type", 400)->where("active_type", "in", [4])->where("status", 0)->update(["status" => 1]);
        $hostIds = \think\Db::name("run_maping")->where("from_type", 400)->where("active_type", 4)->where("status", 1)->column("host_id");
        if (!empty($hostIds)) {
            \think\Db::name("host")->whereIn("id", $hostIds)->update(["domainstatus" => "Deleted"]);
        }
        return json(["message" => "任务已执行成功"]);
    }
    public function index()
    {
        $this->assign("Title", "说明");
        return $this->fetch("/index");
    }
}

?>