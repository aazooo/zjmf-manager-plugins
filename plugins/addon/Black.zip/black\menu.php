<?php
return [["name" => "公告设置", "url" => "Black://AdminIndex/config", "custom" => 0, "lang" => ["chinese" => "公告设置", "chinese_tw" => "公告設定", "english" => "Announcement settings"]], ["name" => "违规列表", "url" => "Black://AdminIndex/list", "custom" => 0, "lang" => ["chinese" => "违规列表", "chinese_tw" => "違規清單", "english" => "Violation list"]], ["name" => "添加违规", "url" => "Black://AdminIndex/black", "custom" => 0, "lang" => ["chinese" => "添加违规", "chinese_tw" => "添加違規", "english" => "Add violation"]]];

?>