<?php
namespace addons\black\controller\clientarea;

class IndexController extends \app\home\controller\PluginHomeBaseController
{
    public function index()
    {
        $data["notice"] = \think\Db::name("configuration")->where("setting", "violations_notice")->value("value");
        $list = \think\Db::name("violations")->select()->toArray();
        $this->assign("List", $list);
        $this->assign("Data", $data);
        $this->assign("Title", "违规用户公示");
        return $this->fetch("/index");
    }
}

?>