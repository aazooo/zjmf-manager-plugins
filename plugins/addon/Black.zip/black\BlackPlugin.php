<?php
namespace addons\black;

class BlackPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "Black", "title" => "违规用户公示", "description" => "此插件可实现后台设置", "status" => 1, "author" => "Think", "version" => "1.0.0", "module" => "addons", "lang" => ["chinese" => "违规用户公示", "chinese_tw" => "違規用戶公示", "english" => "Illegal user publicity"]];
    public function install()
    {
        $sql = ["DROP TABLE IF EXISTS `shd_violations`", "CREATE TABLE `shd_violations` (  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,  `user` varchar(255) DEFAULT NULL COMMENT '奖品',  `describe` varchar(255) DEFAULT NULL COMMENT '违规内容',  `time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态',  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8", "INSERT INTO shd_configuration (setting, value) VALUES ('violations_notice','这是公告');"];
        foreach ($sql as $v) {
            \think\Db::query($v);
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>