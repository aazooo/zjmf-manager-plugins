<?php
return [["name" => "违规用户通告", "url" => "Black://Index/index", "fa_icon" => "bx bx-bell bx-tada", "lang" => ["chinese" => "违规用户通告", "chinese_tw" => "違規用戶通告", "english" => "Illegal user notification"], "child" => []]];

?>