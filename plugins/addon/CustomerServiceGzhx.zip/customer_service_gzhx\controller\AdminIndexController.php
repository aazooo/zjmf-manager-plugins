<?php
namespace addons\customer_service_gzhx\controller;

class AdminIndexController extends \app\admin\controller\PluginAdminBaseController
{
    public $data;
    public function initialize()
    {
        parent::initialize();
        $this->data = $_POST;
    }
    public function success($arr)
    {
        echo json_encode(["status" => 1, "encrypt" => 1, "info" => $arr]);
        exit;
    }
    public function error($arr)
    {
        echo json_encode(["status" => 0, "info" => $arr]);
        exit;
    }
    public function index()
    {
        if (!empty($this->data["action"])) {
            switch ($this->data["action"]) {
                case "upload":
                    preg_match("/^data:image\\/(.+?);base64,(.+?)\$/isu", $this->data["data"], $match);
                    $path = CMF_ROOT . "public/upload/customer_service/";
                    if (!is_dir($path)) {
                        mkdir($path, 493, true);
                    }
                    $fname = $this->data["type"] . "_" . $this->data["id"] . ".png";
                    file_put_contents($path . $fname, base64_decode($match[2]));
                    $CustomerService = \Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["id"])->find();
                    if (empty($CustomerService)) {
                        \Think\Db::name("customer_service_gzhx")->insert(["id" => $this->data["id"], $this->data["type"] => "/upload/customer_service/" . $fname . "?" . time()]);
                    } else {
                        \Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["id"])->update([$this->data["type"] => "/upload/customer_service/" . $fname . "?" . time()]);
                    }
                    $Users = \Think\Db::name("user")->where("id", "=", $this->data["id"])->find();
                    $Users["CustomerService"] = \Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["id"])->find();
                    $this->success($Users);
                    exit;
                    break;
                case "status":
                    $CustomerService = \Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["id"])->find();
                    if (empty($CustomerService)) {
                        \Think\Db::name("customer_service_gzhx")->insert(["id" => $this->data["id"], "status" => $this->data["status"], "face" => "/plugins/addons/customer_service_gzhx/template/header01.png", "wechat_pic" => ""]);
                    } else {
                        \Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["id"])->update(["status" => $this->data["status"]]);
                    }
                    $Users = \Think\Db::name("user")->where("id", "=", $this->data["id"])->find();
                    $Users["CustomerService"] = \Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["id"])->find();
                    $this->success($Users);
                    exit;
                    break;
                case "set":
                    $CustomerService = \Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["data"]["id"])->find();
                    if (empty($this->data["data"]["status"])) {
                        $this->data["data"]["status"] = 1;
                    }
                    if (empty($CustomerService)) {
                        $this->data["data"]["face"] = "/plugins/addons/customer_service_gzhx/template/header01.png";
                        \Think\Db::name("customer_service_gzhx")->insert($this->data["data"]);
                    } else {
                        \Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["data"]["id"])->update($this->data["data"]);
                    }
                    $this->success(\Think\Db::name("customer_service_gzhx")->where("id", "=", $this->data["data"]["id"])->find());
                    exit;
                    break;
                case "install":
                    if ($this->data["install"] == 1) {
                        $clientarea_default_themes = file_get_contents(dirname(__FILE__) . "/clientarea_default_themes.txt") ?: "default";
                        \Think\Db::name("configuration")->where("setting", "=", "clientarea_default_themes")->update(["value" => $clientarea_default_themes]);
                    } else {
                        if (!is_dir(CMF_ROOT . "public/themes/clientarea/GzhxCustomerService")) {
                            mkdir(CMF_ROOT . "public/themes/clientarea/GzhxCustomerService", 493, true);
                        }
                        if (!file_exists(CMF_ROOT . "public/themes/clientarea/GzhxCustomerService/clientarea.tpl")) {
                            $data = file_get_contents("http://zjmf.03s.cn/themes/clientarea/default/clientarea.tpl");
                            if (empty($data)) {
                                $this->error("下载模版失败");
                                exit;
                            }
                            if (!file_put_contents(CMF_ROOT . "public/themes/clientarea/GzhxCustomerService/clientarea.tpl", $data)) {
                                $this->error("下载模版失败，请检查写入权限");
                                exit;
                            }
                        }
                        if (!file_exists(CMF_ROOT . "public/themes/clientarea/GzhxCustomerService/theme.config")) {
                            $themeConfig = "name:\"GzhxCustomerService\"\r\ndescription:\"GzhxCustomerService\"\r\nauthor:\"GZHX Technology\"\r\nconfig-parent-theme:\"default\"";
                            if (!file_put_contents(CMF_ROOT . "public/themes/clientarea/GzhxCustomerService/theme.config", $themeConfig)) {
                                $this->error("下载模版失败，请检查写入权限");
                                exit;
                            }
                        }
                        $clientarea_default_themes = \Think\Db::name("configuration")->where("setting", "=", "clientarea_default_themes")->value("value") ?: "default";
                        if (!file_put_contents(dirname(__FILE__) . "/clientarea_default_themes.txt", $clientarea_default_themes)) {
                            $this->error("下载模版失败，请检查写入权限");
                            exit;
                        }
                        \Think\Db::name("configuration")->where("setting", "=", "clientarea_default_themes")->update(["value" => "GzhxCustomerService"]);
                    }
                    $clientarea_default_themes = \Think\Db::name("configuration")->where("setting", "=", "clientarea_default_themes")->value("value") ?: "default";
                    $install = false;
                    if ($clientarea_default_themes == "GzhxCustomerService") {
                        $install = true;
                    }
                    $this->success($install);
                    exit;
                    break;
                case "get":
                    $clientarea_default_themes = \Think\Db::name("configuration")->where("setting", "=", "clientarea_default_themes")->value("value") ?: "default";
                    $Users = \Think\Db::name("user")->where("is_sale", "=", 1)->select()->toArray();
                    $CustomerService = \Think\Db::name("customer_service_gzhx")->select()->toArray();
                    $CustomerService = array_column($CustomerService, NULL, "id");
                    foreach ($Users as $key => $item) {
                        $Users[$key]["CustomerService"] = $CustomerService[$item["id"]];
                    }
                    $install = false;
                    if ($clientarea_default_themes == "GzhxCustomerService") {
                        $install = true;
                    }
                    $this->success(["user" => $Users, "install" => $install]);
                    break;
            }
        }
        $this->assign("Title", "客服设置");
        return $this->fetch("/index");
    }
}

?>