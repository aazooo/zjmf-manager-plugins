<?php
return [["name" => "客服管理", "url" => "CustomerServiceGzhx://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "客服管理", "chinese_tw" => "客服管理", "english" => "CustomerService"]]];

?>