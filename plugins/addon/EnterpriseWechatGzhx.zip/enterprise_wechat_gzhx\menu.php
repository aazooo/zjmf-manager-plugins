<?php
return [["name" => "基本设置", "url" => "EnterpriseWechatGzhx://AdminIndex/index", "custom" => 0], ["name" => "工单客服设置", "url" => "EnterpriseWechatGzhx://AdminIndex/manual", "custom" => 0], ["name" => "消息发送日志", "url" => "EnterpriseWechatGzhx://AdminIndex/log", "custom" => 0]];

?>