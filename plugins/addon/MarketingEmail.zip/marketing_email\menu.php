<?php
return [["name" => "系统设置", "url" => "MarketingEmail://AdminIndex/setting", "custom" => 0, "lang" => ["chinese" => "系统设置", "chinese_tw" => "系統設置", "english" => "System settings"]], ["name" => "发送营销邮件", "url" => "MarketingEmail://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "发送营销邮件", "chinese_tw" => "發送营销邮件", "english" => "Send Marketing emails"]]];

?>