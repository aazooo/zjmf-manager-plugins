<?php

return [
    [
        'name' => '到期产品删除IP记录',
        'url' => 'ExpiredIpLog://AdminIndex/index',
        'custom' => 0,
        'lang' => [
            'chinese' => '到期产品删除IP记录',
            'chinese_tw' => '到期产品删除IP记录',
            'english' => 'Delete IP records for expired products'
        ]
    ]
];
