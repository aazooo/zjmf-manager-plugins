<?php
namespace addons\turntable_gzhx;

class TurntableGzhxPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "TurntableGzhx", "title" => "大转盘活动插件", "description" => "大转盘活动插件", "status" => 1, "author" => "GZHX Technology", "version" => "1.0.8", "module" => "addons", "not_install" => true];
    public function install()
    {
        $DbConfig = \Think\Db::getConfig();
        $SqlData = ["gzhx_activity" => "CREATE TABLE `" . $DbConfig["prefix"] . "gzhx_activity`  (`id` int(11) NOT NULL AUTO_INCREMENT,`plugin` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`setting` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,`status` tinyint(2) NULL DEFAULT 1,`start_time` date NULL DEFAULT NULL,`end_time` date NULL DEFAULT NULL,PRIMARY KEY (`id`) USING BTREE,INDEX `plugin`(`plugin`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;", "gzhx_activity_group" => "CREATE TABLE `" . $DbConfig["prefix"] . "gzhx_activity_group`  (`id` int(11) NOT NULL AUTO_INCREMENT,`name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`setting` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,`plugin` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`gid` int(11) NULL DEFAULT 0,`num` int(11) NULL DEFAULT 100,`ord` int(11) NULL DEFAULT 0,`propaganda` varchar(4000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',PRIMARY KEY (`id`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;", "gzhx_activity_prize_setting" => "CREATE TABLE `" . $DbConfig["prefix"] . "gzhx_activity_prize_setting`  (`id` int(11) NOT NULL AUTO_INCREMENT,`name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`winning` int(10) NULL DEFAULT 0,`plugin` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`ord` int(5) NULL DEFAULT 0,`setting` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,PRIMARY KEY (`id`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;", "gzhx_activity_user" => "CREATE TABLE `" . $DbConfig["prefix"] . "gzhx_activity_user`  (`id` int(11) NOT NULL AUTO_INCREMENT,`aid` int(11) NULL DEFAULT 0,`uid` int(11) NULL DEFAULT NULL,`plugin` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,`status` tinyint(2) NULL DEFAULT 1,`msg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`prize_id` int(11) NULL DEFAULT 0,`add_time` datetime(0) NULL DEFAULT NULL,`code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`prize_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`user_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`error` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,PRIMARY KEY (`id`) USING BTREE,INDEX `plugin`(`plugin`) USING BTREE,INDEX `uid`(`uid`) USING BTREE,INDEX `status`(`status`) USING BTREE,INDEX `type`(`type`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;", "gzhx_prize" => "CREATE TABLE `" . $DbConfig["prefix"] . "gzhx_prize`  (`id` int(11) NOT NULL AUTO_INCREMENT,`uid` int(11) NULL DEFAULT 0,`prize_id` int(11) NULL DEFAULT 0,`add_time` datetime(0) NULL DEFAULT NULL,`code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`prize_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`user_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`plugin` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',`error` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,PRIMARY KEY (`id`) USING BTREE,INDEX `prize_id`(`prize_id`) USING BTREE,INDEX `uid`(`uid`) USING BTREE,INDEX `plugin`(`plugin`) USING BTREE) ENGINE = InnoDB AUTO_INCREMENT = 78 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;"];
        $tableList = \Think\Db::query("SELECT table_name FROM information_schema.TABLES WHERE TABLE_SCHEMA='" . $DbConfig["database"] . "'");
        $tableList = array_column($tableList, "table_name");
        foreach ($SqlData as $key => $sql) {
            if (!in_array($DbConfig["prefix"] . $key, $tableList)) {
                \Think\Db::query($sql);
            }
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>