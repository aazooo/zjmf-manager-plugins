<?php
return [["name" => "大转盘活动", "url" => "TurntableGzhx://Index/index", "fa_icon" => "bx bxs-grid-alt", "lang" => ["chinese" => "大转盘活动", "chinese_tw" => "大转盘活动", "english" => "Turntable"]]];

?>