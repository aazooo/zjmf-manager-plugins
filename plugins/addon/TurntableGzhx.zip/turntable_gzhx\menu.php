<?php
return [["name" => "活动设置", "url" => "TurntableGzhx://AdminIndex/activity", "custom" => 0], ["name" => "奖品设置", "url" => "TurntableGzhx://AdminIndex/index", "custom" => 0], ["name" => "中奖记录", "url" => "TurntableGzhx://AdminIndex/winningrecord", "custom" => 0], ["name" => "抽奖链接", "url" => "/plugins/addons/turntable_gzhx/template/index.html?from=NYUXEJSK", "custom" => 1]];

?>