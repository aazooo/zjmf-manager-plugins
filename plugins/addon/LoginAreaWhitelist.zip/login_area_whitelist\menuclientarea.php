<?php
return [["name" => "地区白名单", "url" => "LoginAreaWhitelist://Index/index", "fa_icon" => "bx bxs-grid-alt", "lang" => ["chinese" => "地区白名单", "chinese_tw" => "地区白名单", "english" => "Area Whitelist"]], ["name" => "登录日志", "url" => "LoginAreaWhitelist://Index/log", "fa_icon" => "bx bxs-grid-alt", "lang" => ["chinese" => "登录日志", "chinese_tw" => "登录日志", "english" => "Area Log"]]];

?>