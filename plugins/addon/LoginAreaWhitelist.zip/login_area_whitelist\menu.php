<?php
return [["name" => "用户问题管理", "url" => "LoginAreaWhitelist://AdminIndex/index", "custom" => 0], ["name" => "登录日志", "url" => "LoginAreaWhitelist://AdminIndex/log", "custom" => 0]];

?>