<?php
namespace addons\login_area_whitelist\ip;

class City
{
    public $reader;
    public function __construct()
    {
        $db = dirname(__FILE__) . "/ipipfree.ipdb";
        $this->reader = new Reader($db);
    }
    public function find($ip, $language)
    {
        $addr = $this->reader->find($ip, $language);
        return implode("", $addr);
    }
    public function findMap($ip, $language)
    {
        return $this->reader->findMap($ip, $language);
    }
    public function findInfo($ip, $language)
    {
        $map = $this->findMap($ip, $language);
        if (NULL === $map) {
            return NULL;
        }
        return new CityInfo($map);
    }
}

?>