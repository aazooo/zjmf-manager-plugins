<?php
hook_add("after_daily_cron", function ($param) {
    return "test";
});

?>