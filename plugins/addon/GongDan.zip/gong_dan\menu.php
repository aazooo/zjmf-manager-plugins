<?php
return [["name" => "功能设置", "url" => "GongDan://AdminIndex/index", "custom" => 0]];

?>