<?php
return ["title" => "Plug-in message push", "help" => "If you have any questions, please contact the author."];

?>