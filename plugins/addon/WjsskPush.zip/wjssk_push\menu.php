<?php
return [["name" => "推送配置", "url" => "WjsskPush://WjsskPush/set", "custom" => 0, "lang" => ["chinese" => "推送配置", "chinese_tw" => "推送配置", "english" => "Push configuration"]], ["name" => "推送日志", "url" => "WjsskPush://WjsskPush/log", "custom" => 0, "lang" => ["chinese" => "推送日志", "chinese_tw" => "推送日志", "english" => "Push log"]]];

?>