<?php

return [
    [
        'name' => '基础配置',
        'url' => 'ProductDivert://AdminIndex/setting',
        'custom' => 0
    ],
    [
        'name' => '转移列表',
        'url' => 'ProductDivert://AdminIndex/index',
        'custom' => 0
    ]
];
