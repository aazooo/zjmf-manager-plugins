<?php
return ["PLUGIN_INSTALL_ERROR" => "The plug-in installation is abnormal. Please uninstall and try again", "STATUS_DESCRIBE" => ["1" => "待接收", "2" => "已完成", "3" => "已关闭", "4" => "已拒绝"]];

?>