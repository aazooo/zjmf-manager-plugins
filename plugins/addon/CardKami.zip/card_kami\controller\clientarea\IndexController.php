<?php
namespace addons\card_kami\controller\clientarea;

class IndexController extends \app\home\controller\PluginHomeBaseController
{
    public function index()
    {
        $notes = \think\Db::name("card_kami_set")->where("id", 1)->value("notes");
        $open = \think\Db::name("card_kami_set")->where("id", 1)->value("open");
        $buyurl = \think\Db::name("card_kami_set")->where("id", 1)->value("buyurl");
        $this->assign("notes", $notes);
        $this->assign("open", $open);
        $this->assign("buyurl", $buyurl);
        $this->assign("Title", "卡密充值");
        return $this->fetch("/index");
    }
    public function recharge()
    {
        $userid = request()->uid;
        $data = $this->request->post();
        $cami = isset($data["cami"]) ? $data["cami"] : NULL;
        $cami = isset($data["cami"]) ? $data["cami"] : NULL;
        if (empty($data["cami"])) {
            $response = ["code" => 400, "msg" => "请输入充值卡卡密"];
            return json($response);
        }
        $cardInfo = \think\Db::name("card_kami_list")->where("cami", $cami)->find();
        if (!$cardInfo) {
            $response = ["code" => 400, "msg" => "卡密不存在"];
            return json($response);
        }
        if ($cardInfo["status"] == 0) {
            $result = \think\Db::name("card_kami_list")->where("cami", $cami)->find();
            $clients = \think\Db::name("clients")->where("id", $userid)->find();
            $money = $result["money"];
            $credit = $clients["credit"];
            $newcredit = $money + $credit;
            $upnewcredit = \think\Db::name("clients")->where("id", $userid)->update(["credit" => $newcredit]);
            if ($upnewcredit !== false) {
                $upcami = \think\Db::name("card_kami_list")->where("cami", $cami)->update(["status" => 1, "uid" => $userid, "username" => $clients["username"], "usagetime" => time()]);
                $data = ["uid" => $userid, "create_time" => time(), "description" => "用户" . $clients["username"] . " - [UID" . $userid . "]，使用卡密【" . $cami . "】成功充值" . $money . "元，卡密编号：" . $result["id"] . "", "amount" => $money, "balance" => $newcredit];
                \think\Db::name("credit")->insert($data);
                $datainvoices = ["uid" => $userid, "create_time" => time(), "due_time" => time(), "paid_time" => time(), "update_time" => time(), "subtotal" => $money, "total" => $money, "payment" => "UserCustom", "status" => "Paid", "type" => "recharge"];
                \think\Db::name("invoices")->insert($datainvoices);
                $insertedId = \think\Db::name("invoices")->getLastInsID();
                $datainvoice_items = ["invoice_id" => $insertedId, "uid" => $userid, "type" => "recharge", "due_time" => time(), "description" => "用户" . $clients["username"] . " - [UID" . $userid . "]，使用卡密【" . $cami . "】成功充值" . $money . "元，充值时间：" . date("Y-m-d H:i:s", time()) . "\n", "description" => "用户" . $clients["username"] . " - [UID" . $userid . "]，使用卡密【" . $cami . "】成功充值" . $money . "元，充值时间：" . date("Y-m-d H:i:s", time()) . "", "amount" => $money];
                \think\Db::name("invoice_items")->insert($datainvoice_items);
                $Switch = \think\Db::name("card_kami_set")->where(["id" => 1])->find();
                $notifyValue = $Switch["notice"] == 1;
                $sendToDingTalk = $Switch["dingTalkswitch"] == 1;
                $sendToFeishu = $Switch["feishuswitch"] == 1;
                $sendToWeChat = $Switch["wechatswitch"] == 1;
                $sendToTGChat = $Switch["tgswitch"] == 1;
                $TGtoken = $Switch["tgtoken"];
                $TGchatid = $Switch["tgchatid"];
                $message = "【卡密充值通知】\n用户ID：" . $userid . " \n用户名称：" . $clients["username"] . " \n充值金额：" . $money . " 元\n账单编号：" . $insertedId . " \n卡密编号：" . $result["id"] . " \n充值卡密：" . $cami . " \n充值时间：" . date("Y-m-d H:i:s", time()) . "\n\n消息来源【" . $Switch["sitename"] . " 】卡密充值【机器人版】";
                if ($notifyValue) {
                    if ($sendToFeishu) {
                        $feishuWebhookUrl = $Switch["feishuhook"];
                        $feishuData = json_encode(["msg_type" => "text", "content" => ["text" => $message]]);
                        $this->sendWebhookNotification($feishuWebhookUrl, $feishuData);
                    }
                    if ($sendToDingTalk) {
                        $dingtalkWebhookUrl = $Switch["dingTalkhook"];
                        $dingtalkData = ["msgtype" => "text", "text" => ["content" => $message]];
                        $this->sendWebhookNotification($dingtalkWebhookUrl, json_encode($dingtalkData));
                    }
                    if ($sendToWeChat) {
                        $wechatWebhookUrl = $Switch["wechathook"];
                        $wechatData = ["msgtype" => "text", "text" => ["content" => $message]];
                        $this->sendWebhookNotification($wechatWebhookUrl, json_encode($wechatData));
                    }
                    if ($sendToTGChat) {
                        $telegramBotToken = $TGtoken;
                        $telegramChatId = $TGchatid;
                        $telegramMessage = urlencode($message);
                        $telegramUrl = "https://api.telegram.org/bot" . $telegramBotToken . "/sendMessage?chat_id=" . $telegramChatId . "&text=" . $telegramMessage;
                        $this->sendTelegramNotification($telegramUrl);
                    }
                }
                $response = ["code" => 200, "msg" => "使用卡密：" . $cami . " 成功充值 " . $money . " 元"];
                return json($response);
            }
            $response = ["code" => 400, "msg" => "充值失败"];
            return json($response);
        }
        if ($cardInfo["status"] == 1) {
            $response = ["code" => 400, "msg" => "卡密已被使用"];
            return json($response);
        }
        $response = ["code" => 400, "msg" => "无效的卡密状态"];
        return json($response);
    }
    private function sendWebhookNotification($webhookUrl, $data)
    {
        $ch = curl_init($webhookUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
        $response = curl_exec($ch);
        curl_close($ch);
    }
    private function sendTelegramNotification($telegramUrl)
    {
        $ch = curl_init($telegramUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        $response = curl_exec($ch);
        curl_close($ch);
    }
}

?>