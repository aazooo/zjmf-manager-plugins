<?php
return [["name" => "功能设置", "url" => "CardKami://AdminIndex/setting", "custom" => 0, "lang" => ["chinese" => "功能设置", "chinese_tw" => "功能設置", "english" => "Function settings"]], ["name" => "生成卡密", "url" => "CardKami://AdminIndex/addrandkami", "custom" => 0, "lang" => ["chinese" => "生成卡密", "chinese_tw" => "生成卡密", "english" => "Generate Card Secret"]], ["name" => "卡密列表", "url" => "CardKami://AdminIndex/kamilist", "custom" => 0, "lang" => ["chinese" => "卡密列表", "chinese_tw" => "卡密列表", "english" => "Card Secret List"]]];

?>