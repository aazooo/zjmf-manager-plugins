<?php
return [["name" => "充值卡充值", "url" => "", "fa_icon" => "bx bx-health", "lang" => ["chinese" => "充值卡充值", "chinese_tw" => "充值卡增值", "english" => "Recharge card recharge"], "child" => [["name" => "卡密充值", "url" => "CardKami://Index/index", "fa_icon" => "bx bx-bitcoin", "lang" => ["chinese" => "卡密充值", "chinese_tw" => "卡密增值", "english" => "Recharge"], "child" => []]]]];

?>