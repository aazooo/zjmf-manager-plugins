<?php
/*
 *  自定义菜单
 */
return [
    [
        'name' => '主机列表',
        'url'  => 'CloudGzhx://AdminIndex/index',
        'custom' => 0,
    ],
    [
        'name' => '手动开机处理',
        'url'  => 'CloudGzhx://AdminIndex/manual',
        'custom' => 0,
    ],
    [
        'name' => '特价机器订单',
        'url'  => 'CloudGzhx://AdminIndex/specialofferorder',
        'custom' => 0,
    ],
    [
        'name' => '特价销售机器',
        'url'  => 'CloudGzhx://AdminIndex/specialoffer',
        'custom' => 0,
    ],
    [
        'name' => '系统日志',
        'url'  => 'CloudGzhx://AdminIndex/operate_log',
        'custom' => 0,
    ]
];