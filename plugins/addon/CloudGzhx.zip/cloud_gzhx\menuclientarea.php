<?php
/*
 *  前台自定义菜单
 */
return [
    [
        'name' => '精品云主机', # 菜单名称 默认为一级菜单
        'url'  => 'CloudGzhx://Index/index', # 菜单路由 (若有子菜单,此值留空)
        'fa_icon' => 'bx bxs-grid-alt', # 菜单图标 支持bootstrap
        'lang' => [ # 菜单多语言
            'chinese' => '精品云主机', # 中文
            'chinese_tw' => '精品云主机', # 台湾
            'english' => 'Cloud Manage', # 英文
        ],'child' => [  # 子菜单 没有定义为空数组
            [
                'name' => '主机管理', # 链接名称
                'url'  => 'CloudGzhx://Index/index', # 链接格式   插件名://控制器名/方法   菜单路由 (若有子菜单,此值留空)
                'fa_icon' => '',
                    'lang' => [ # 菜单多语言
                    'chinese' => '主机管理', # 中文
                    'chinese_tw' => '主机管理', # 台湾
                    'english' => 'Cloud Manage', # 英文
                ],
        'child' => []
    ],
    [
        'name' => '购买云主机', # 链接名称
        'url'  => 'CloudGzhx://Index/buy', # 链接格式   插件名://控制器名/方法
        'fa_icon' => '',
        'lang' => [ # 菜单多语言
            'chinese' => '购买云主机', # 中文
            'chinese_tw' => '购买云主机', # 台湾
            'english' => 'Buy', # 英文
        ],
        'child' => []
    ],
    [
        'name' => '特价云主机', # 链接名称
        'url'  => 'CloudGzhx://Index/special_offer_buy', # 链接格式   插件名://控制器名/方法
        'fa_icon' => '',
        'lang' => [ # 菜单多语言
            'chinese' => '特价云主机', # 中文
            'chinese_tw' => '特价云主机', # 台湾
            'english' => 'Special Offer', # 英文
        ],
        'child' => []
    ],
    [
        'name' => '日志', # 链接名称
        'url'  => 'CloudGzhx://Index/log', # 链接格式   插件名://控制器名/方法
        'fa_icon' => '',
        'lang' => [ # 菜单多语言
            'chinese' => '日志', # 中文
            'chinese_tw' => '日志', # 台湾
            'english' => 'Log', # 英文
        ],
        'child' => []
    ],

]
    ]
];