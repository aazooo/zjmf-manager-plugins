<?php
namespace addons\sky_white;

class SkyWhitePlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "SkyWhite", "title" => "在线过白", "description" => "蒲公英机房免API过白", "status" => 1, "author" => "天空 QQ:3557289004", "version" => "1.1", "module" => "addons"];
    public function install()
    {
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>