<?php
namespace addons\sky_white\controller;

class AdminIndexController extends \app\admin\controller\PluginAdminBaseController
{
    public function white()
    {
        $url = shd_addon_url("SkyWhite://AdminIndex/white");
        if ($_POST["user"] && $_POST["pass"]) {
            $cookie = \addons\sky_white\common\Login::cookie($_POST["user"], $_POST["pass"]);
            if (!$cookie) {
                exit("<script>alert('登录失败');parent.location.href='" . $url . "';</script>");
            }
            \addons\sky_white\common\Login::mysql($cookie);
            exit("<script>alert('登录成功');parent.location.href='" . $url . "';</script>");
        }
        $config = \think\Db::name("plugin")->where("name", "SkyWhite")->value("config");
        $config = json_decode($config, true);
        $this->assign("Title", "在线过白");
        $this->assign("Config", $config);
        return $this->fetch("/white");
    }
}

?>