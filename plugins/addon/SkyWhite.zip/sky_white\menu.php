<?php
return [["name" => "信息配置", "url" => "SkyWhite://AdminIndex/white", "custom" => 0]];

?>