<?php
namespace addons\sky_white\controller\clientarea;

class IndexController extends \app\home\controller\PluginHomeBaseController
{
    public function white()
    {
        if ($_POST["ip"] && $_POST["web_domain"]) {
            $config = \think\Db::name("plugin")->where("name", "SkyWhite")->value("config");
            $config = json_decode($config, true);
            if (!$config["user"] || !$config["pass"]) {
                return ["status" => 0, "msg" => "未配置信息"];
            }
            if ($config["date"] <= date("Y/m/d")) {
                $config = \addons\sky_white\common\Login::cookie($config["user"], $config["pass"]);
                if (!$config) {
                    return ["status" => 0, "msg" => "登录失败"];
                }
                \addons\sky_white\common\Login::mysql($config);
            }
            $icpurl = file_get_contents("https://v.api.aa1.cn/api/icp/index.php?url=" . $_POST["web_domain"]);
            $icp = json_decode($icpurl, true);
            if ($icp["icp"] == "未备案") {
                return ["status" => 0, "msg" => "未备案"];
            }
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://user.pgyidc.com/template/addlist");
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(["addr" => $_POST["web_domain"], "ip" => $_POST["ip"]]));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ["Cookie: PHPSESSID=" . $config["cookie"]]);
            $response = curl_exec($ch);
            if (curl_errno($ch)) {
                return ["status" => 0, "msg" => curl_error($ch)];
            }
            curl_close($ch);
            if ($response != "0") {
                return ["status" => 0, "msg" => "过白失败"];
            }
            return ["status" => 1, "msg" => "过白成功"];
        }
        $this->assign("Title", "在线过白");
        return $this->fetch("/white");
    }
}

?>