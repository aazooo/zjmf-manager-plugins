<?php
namespace addons\sky_white\common;

class Login
{
    public static function cookie($user, $pass)
    {
        $cookieurl = file_get_contents("http://api.52-tk.cn/api/dandelion/cookie.php?user=" . $user . "&pass=" . $pass);
        $cookie = json_decode($cookieurl, true);
        if ($cookie["code"] != 0) {
            return false;
        }
        $json = ["user" => $user, "pass" => $pass, "date" => date("Y/m/d"), "cookie" => $cookie["data"]];
        return $json;
    }
    public static function mysql($json)
    {
        \think\Db::name("plugin")->where("name", "SkyWhite")->update(["config" => json_encode($json)]);
        return true;
    }
}

?>