<?php
return [["name" => "上游设置", "url" => "ProductSyn://AdminIndex/index", "custom" => 0]];

?>