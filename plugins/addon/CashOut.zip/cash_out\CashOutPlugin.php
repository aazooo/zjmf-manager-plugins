<?php
namespace addons\cash_out;

class CashOutPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "CashOut", "title" => "预存款提现插件", "description" => "此插件可实现用户提现余额，后台查看提现列表，并对修改提现状态", "status" => 1, "author" => "Think", "version" => "1.1.0", "module" => "addons", "lang" => ["chinese" => "预存款提现插件", "chinese_tw" => "用戶余額提現插件", "english" => "User balance recovery plug-in"]];
    public function install()
    {
        $sql = ["ALTER TABLE shd_affiliates_withdraw ADD username varchar(255) DEFAULT Null;", "ALTER TABLE shd_affiliates_withdraw ADD qrcode varchar(255) DEFAULT Null;", "ALTER TABLE shd_affiliates_withdraw ADD way varchar(255) DEFAULT Null;", "ALTER TABLE shd_affiliates_withdraw ADD name varchar(255) DEFAULT Null;", "ALTER TABLE shd_affiliates_withdraw ADD charge decimal(12,2) DEFAULT 0.00;", "INSERT INTO shd_configuration (setting, value) VALUES ('withdraw_is','1');", "INSERT INTO shd_configuration (setting, value) VALUES ('withdraw_is_real','1');", "INSERT INTO shd_configuration (setting, value) VALUES ('withdraw_charge','10');", "INSERT INTO shd_configuration (setting, value) VALUES ('withdraw_is_qq','1');", "INSERT INTO shd_configuration (setting, value) VALUES ('withdraw_is_bank','1');", "INSERT INTO shd_configuration (setting, value) VALUES ('withdraw_is_wx','1');", "INSERT INTO shd_configuration (setting, value) VALUES ('withdraw_is_zfb','1');", "INSERT INTO shd_configuration (setting, value) VALUES ('withdraw_notice','这里是公告');"];
        foreach ($sql as $v) {
            \think\Db::query($v);
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
    public function clientLogin()
    {
    }
}

?>