<?php
return [["name" => "余额提现", "url" => "CashOut://Index/apply", "fa_icon" => "bx bx-dollar-circle", "lang" => ["chinese" => "余额提现", "chinese_tw" => "余額提現", "english" => "Withdrawal of balance"], "child" => []]];

?>