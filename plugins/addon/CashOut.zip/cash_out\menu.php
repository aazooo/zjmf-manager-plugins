<?php
return [["name" => "提现设置", "url" => "CashOut://AdminIndex/config", "custom" => 0, "lang" => ["chinese" => "提现设置", "chinese_tw" => "提現設置", "english" => "Withdrawal config"]], ["name" => "提现列表", "url" => "CashOut://AdminIndex/list", "custom" => 0, "lang" => ["chinese" => "提现列表", "chinese_tw" => "提現列表", "english" => "Withdrawal list"]]];

?>