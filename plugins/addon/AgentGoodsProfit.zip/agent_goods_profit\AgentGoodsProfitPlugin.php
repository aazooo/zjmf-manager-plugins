<?php
namespace addons\agent_goods_profit;

class AgentGoodsProfitPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "AgentGoodsProfit", "title" => "代理商品利润计算", "description" => "用于计算资源池代理商品有成本的情况下的利润", "status" => 1, "author" => "顺戴网络", "version" => "1.0", "module" => "addons", "lang" => ["chinese" => "代理商品利润计算", "chinese_tw" => "代理商品利潤計算", "english" => "Calculation of agent commodity profit"]];
    public function install()
    {
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>