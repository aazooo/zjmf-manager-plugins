<?php
return [["name" => "代理商品利润计算", "url" => "AgentGoodsProfit://AdminIndex/index", "custom" => 0, "lang" => ["chinese" => "代理商品利润计算", "chinese_tw" => "代理商品利潤計算", "english" => "Calculation of agent commodity profit"]]];

?>