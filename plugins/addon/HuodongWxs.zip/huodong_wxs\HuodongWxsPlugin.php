<?php
namespace addons\huodong_wxs;

class HuodongWxsPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "HuodongWxs", "title" => "HuodongWxs", "description" => "活动插件，自动设置无用户组为指定用户组 方便设置活动。", "status" => 1, "author" => "武小帅", "version" => "1.0", "module" => "addons", "lang" => ["chinese" => "活动插件"]];
    public function install()
    {
        return true;
    }
    public function uninstall()
    {
        return true;
    }
    public function clientLogin()
    {
    }
    public function templateAfterServicedetailSuspended($param)
    {
        return "";
    }
}

?>