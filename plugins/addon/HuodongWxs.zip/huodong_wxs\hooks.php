<?php
hook_add("client_area_head_output", function ($vars) {
    $name = "plugins/addons/huodong_wxs/cache/" . $_SESSION["view_tpl_data"]["Userinfo"]["user"]["id"] . ".txt";
    if (!file_exists($name)) {
        $oids = think\Db::name("clients")->where("id", $_SESSION["view_tpl_data"]["Userinfo"]["user"]["id"])->select();
        $group_name = file_get_contents("plugins/addons/huodong_wxs/config.txt");
        if ($oids[0]["groupid"] == 0) {
            $oids = think\Db::name("clients")->where("id", $_SESSION["view_tpl_data"]["Userinfo"]["user"]["id"])->update(["groupid" => $group_name]);
        }
        $myfile = fopen($name, "w") or exit("Unable to open file!");
        fwrite($myfile, "");
        fclose($myfile);
        echo "<a></a>";
    }
});

?>