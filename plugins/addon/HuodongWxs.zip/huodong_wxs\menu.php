<?php
return [["name" => "设置", "url" => "DailiHook://AdminIndex/addhelp", "custom" => 0, "lang" => ["chinese" => "设置", "chinese_tw" => "设置", "english" => "设置"]]];

?>