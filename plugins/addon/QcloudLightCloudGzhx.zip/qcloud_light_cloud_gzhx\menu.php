<?php
return [["name" => "销售设置", "url" => "QcloudLightCloudGzhx://AdminIndex/index", "custom" => 0]];

?>