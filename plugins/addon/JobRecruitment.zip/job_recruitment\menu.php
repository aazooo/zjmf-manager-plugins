<?php
return [["name" => "基础配置", "url" => "JobRecruitment://AdminIndex/setting", "custom" => 0], ["name" => "招聘岗位管理", "url" => "JobRecruitment://AdminIndex/index", "custom" => 0], ["name" => "应聘人员管理", "url" => "JobRecruitment://AdminIndex/jobs", "custom" => 0]];

?>