<?php
namespace addons\job_recruitment\controller\clientarea;

class IndexController extends \app\home\controller\PluginHomeBaseController
{
    public function jobapply(\think\Request $request)
    {
        $param = $request->param();
        $res = \think\Db::name("plugin")->where("name", "JobRecruitment")->find();
        $res2 = \think\Db::name("job_recruitment_jobs")->select();
        $arr = [];
        $system = json_decode($res["config"], true);
        $data["our"] = $system;
        $data["jobdata"] = $res2;
        $this->assign("Title", "招贤纳士");
        return $this->fetch("/jobapply", $data);
    }
    public function jobapply2()
    {
        try {
            $param = $this->request->param();
            $datas = ["uid" => $param["uid"], "job" => $param["jobname"], "jobresume" => $param["jobresume"], "jobsay" => $param["jobsay"], "jobcontact" => $param["jobcontact"], "date" => time(), "status" => "待审核"];
            \think\Db::name("job_recruitment")->insert($datas);
            return json(["status" => 200, "msg" => "提交成功~"]);
        } catch (\Throwable $e) {
            return json(["status" => 400, "msg" => $e->getMessage()]);
        }
    }
    public function applylist(\think\Request $request)
    {
        $param = $request->param();
        $res = \think\Db::name("plugin")->where("name", "JobRecruitment")->find();
        $res2 = \think\Db::name("job_recruitment")->where("uid", $param["uid"])->select();
        $arr = [];
        $system = json_decode($res["config"], true);
        $count = \think\Db::name("job_recruitment")->count("id");
        $page_info = [];
        $page_info["count"] = $count;
        $page_info["limit"] = $limit;
        $page_info["page"] = ceil($count / $limit);
        $page_info["pages"] = range(1, $page_info["page"]);
        $data["pageInfo"] = $page_info;
        $data["our"] = $system;
        $data["jobdata"] = $res2;
        $this->assign("Title", "应聘列表");
        return $this->fetch("/applylist", $data);
    }
    private function data_pagedata(\think\Request $request, $param)
    {
        $this->page_data_register($request);
        $res_product_divert = \addons\job_recruitment\model\JobRecruitmentModel::getList($param);
        $res_data = $res_product_divert["data"];
        $res_count = $res_product_divert["count"];
        $page_data = $this->page_data_rendering($request, $res_data, $res_count);
        return ["status" => 200, "data" => $res_product_divert["data"], "page_data" => $page_data];
    }
}

?>