<?php
namespace addons\job_recruitment\validate;

class JobRecruitmentValidate extends \think\Validate
{
    protected $rule = ["is_open" => "require|int", "companyname" => "require|varchar", "companynote" => "require|varchar", "workplace" => "require|varchar"];
    protected $message = ["is_open" => "不能为空|只支持数字", "companyname" => "不能为空|请填写公司名", "companynote" => "不能为空|请填写公司介绍", "workplace" => "不能为空|请填写默认工作地点"];
}

?>