<?php
return [["name" => "招贤纳士", "url" => "", "fa_icon" => "bx bx-bar-chart-alt-2", "lang" => ["chinese" => "招贤纳士", "chinese_tw" => "招贤纳士", "english" => "Work Apply"], "child" => [["name" => "岗位招聘", "url" => "JobRecruitment://Index/jobapply", "fa_icon" => "", "lang" => ["chinese" => "岗位招聘", "chinese_tw" => "岗位招聘", "english" => "Work With US"], "child" => []], ["name" => "应聘列表", "url" => "JobRecruitment://Index/applylist", "fa_icon" => "", "lang" => ["chinese" => "应聘列表", "chinese_tw" => "应聘列表", "english" => "Jobapply List"], "child" => []]]]];

?>