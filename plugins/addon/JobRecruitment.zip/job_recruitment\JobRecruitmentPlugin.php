<?php
namespace addons\job_recruitment;

class JobRecruitmentPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "JobRecruitment", "title" => "工作招聘", "description" => "通过本插件，您可以在魔方财务完成工作招聘", "status" => 1, "author" => "<a href=\"https://www.bear-studio.net\">BearStudio Team</a>", "version" => "1.0", "module" => "addons"];
    public function install()
    {
        $sql = ["DROP TABLE IF EXISTS `shd_job_recruitment`", "CREATE TABLE `shd_job_recruitment`  (  `id` int(10) NOT NULL AUTO_INCREMENT,  `uid` int(200) NOT NULL COMMENT '用户id',  `job` varchar(500) NOT NULL DEFAULT '' COMMENT '应聘岗位',  `jobresume` varchar(500) NOT NULL DEFAULT '' COMMENT '应聘简历',  `jobsay` varchar(500) NOT NULL DEFAULT '' COMMENT '其他说明',  `jobcontact` varchar(500) NOT NULL DEFAULT '' COMMENT '联系方式',  `date` int(10) NOT NULL DEFAULT 0 COMMENT '时间',  `status` varchar(500) NOT NULL DEFAULT '' COMMENT '状态',  `note` varchar(500) NOT NULL DEFAULT '' COMMENT '备注',  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"];
        foreach ($sql as $v) {
            \think\Db::execute($v);
        }
        $sql2 = ["DROP TABLE IF EXISTS `shd_job_recruitment_jobs`", "CREATE TABLE `shd_job_recruitment_jobs`  (  `id` int(10) NOT NULL AUTO_INCREMENT,  `jobname` varchar(500) NOT NULL DEFAULT '' COMMENT '岗位名',  `jobimg` varchar(500) NOT NULL DEFAULT '' COMMENT '岗位标志图片',  `jobnote` varchar(500) NOT NULL DEFAULT '' COMMENT '岗位要求',  `salary` varchar(500) NOT NULL DEFAULT '' COMMENT '工作待遇',  `jobplace` varchar(500) NOT NULL DEFAULT '' COMMENT '工作地点',  `jobtime` varchar(500) NOT NULL DEFAULT '' COMMENT '每日工作时长',  `jobexperience` varchar(500) NOT NULL DEFAULT '' COMMENT '工作经验',  `jobnotex` varchar(500) NOT NULL DEFAULT '' COMMENT '备注说明',  `date` int(10) NOT NULL DEFAULT 0 COMMENT '添加时间',  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"];
        foreach ($sql2 as $v2) {
            \think\Db::execute($v2);
        }
        return true;
    }
    public function uninstall()
    {
        $sql = "DROP TABLE IF EXISTS `shd_job_recruitment`";
        \think\Db::execute($sql);
        $sql2 = "DROP TABLE IF EXISTS `shd_job_recruitment_jobs`";
        \think\Db::execute($sql2);
        return true;
    }
}

?>