<?php
namespace addons\job_recruitment\model;

class JobRecruitmentModel
{
}

?>