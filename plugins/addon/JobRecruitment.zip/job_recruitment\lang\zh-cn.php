<?php
return ["PLUGIN_INSTALL_ERROR" => "插件未正常安装。请卸载并重试", "CHANGE_SUCCESS" => "修改成功！"];

?>