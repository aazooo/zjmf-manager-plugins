<?php
return [["name" => "活动设置", "url" => "GroupBuy://AdminIndex/index", "custom" => 0], ["name" => "团长列表", "url" => "GroupBuy://AdminIndex/users", "custom" => 0], ["name" => "团员列表/退款", "url" => "GroupBuy://AdminIndex/member", "custom" => 0]];

?>