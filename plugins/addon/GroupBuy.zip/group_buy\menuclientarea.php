<?php
return [["name" => "拼团秒杀", "url" => "GroupBuy://Index/index", "fa_icon" => "bx bxs-grid-alt", "lang" => ["chinese" => "拼团秒杀", "chinese_tw" => "拼团秒杀", "english" => "Spike"], "child" => [["name" => "活动列表", "url" => "GroupBuy://Index/index", "fa_icon" => "", "lang" => ["chinese" => "活动列表", "chinese_tw" => "活动列表", "english" => "Spike"], "child" => []], ["name" => "我的拼团", "url" => "GroupBuy://Index/my", "fa_icon" => "", "lang" => ["chinese" => "我的拼团", "chinese_tw" => "我的拼团", "english" => "My Spike"], "child" => []]]]];

?>