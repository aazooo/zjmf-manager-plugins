<?php
return ["CLIENT_CARE_AFTER_ORDER_PORDUCT" => "下单产品订购后XX天，选择产品或者产品组后", "ACCEPT" => "接受"];

?>