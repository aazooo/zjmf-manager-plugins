<?php
return [["name" => "销售设置", "url" => "WestDominbygzhx://AdminIndex/index", "custom" => 0]];

?>