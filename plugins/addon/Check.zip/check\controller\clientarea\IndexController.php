<?php
namespace addons\check\controller\clientarea;

class IndexController extends \app\home\controller\PluginHomeBaseController
{
    public function index()
    {
        $data["open"] = \think\Db::name("configuration")->where("setting", "check_is")->value("value");
        $data["check_value"] = \think\Db::name("configuration")->where("setting", "check_value")->value("value");
        foreach ($list as $key => $value) {
            $user = \think\Db::name("clients")->find($value["uid"]);
            $list[$key]["user"] = $user["username"];
        }
        $this->assign("Data", $data);
        $this->assign("Title", "签到中心");
        if (empty($_POST)) {
            return $this->fetch("/index");
        }
        $type = "余额";
        $check_value = \think\Db::name("configuration")->where("setting", "check_value")->value("value");
        $check = \think\Db::name("check")->where("uid", $_POST["uid"])->find();
        $user = \think\Db::name("clients")->where("id", $_POST["uid"])->find();
        $money = $user["credit"];
        if (empty($check)) {
            \think\Db::name("check")->insert(["uid" => $_POST["uid"], "total" => 1, "last_time" => time()]);
            \think\Db::name("check_log")->insert(["uid" => $_POST["uid"], "value" => $check_value, "time" => time()]);
            \think\Db::name("clients")->where("id", $_POST["uid"])->update(["credit" => $money + $check_value]);
            exit(json_encode(["code" => 200, "msg" => "签到成功！获得：" . $type . $check_value]));
        }
        $last_time = date("Y-m-d", $check["last_time"]);
        $now = date("Y-m-d", time());
        if ($last_time == $now) {
            exit(json_encode(["code" => 100, "msg" => "今天你已经签到过了！"]));
        }
        \think\Db::name("clients")->where("id", $_POST["uid"])->update(["credit" => $money + $check_value]);
        \think\Db::name("check")->where("uid", $_POST["uid"])->update(["last_time" => time()]);
        \think\Db::name("check_log")->insert(["uid" => $_POST["uid"], "value" => $check_value, "time" => time()]);
        exit(json_encode(["code" => 200, "msg" => "签到成功！获得：" . $type . $check_value]));
    }
}

?>