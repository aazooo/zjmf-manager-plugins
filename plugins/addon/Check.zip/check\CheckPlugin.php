<?php
namespace addons\check;

class CheckPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "Check", "title" => "用户签到插件", "description" => "此插件可实现用户签到并赠送相应余额", "status" => 1, "author" => "缔梦", "version" => "1.0.0", "module" => "addons", "lang" => ["chinese" => "用户签到", "chinese_tw" => "用戶簽到", "english" => "User check-in"]];
    public function install()
    {
        $sql = ["DROP TABLE IF EXISTS `shd_check`", "DROP TABLE IF EXISTS `shd_check_log`", "CREATE TABLE `shd_check` (  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,  `uid` int(11) DEFAULT NULL COMMENT '签到者',  `total` int(11) DEFAULT NULL COMMENT '总共签到',  `last_time` int(11) NOT NULL DEFAULT '0' COMMENT '上次签到时间',  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8", "CREATE TABLE `shd_check_log` (  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '签到者',  `value` varchar(255) DEFAULT NULL COMMENT '奖励数额',  `time` int(11) NOT NULL DEFAULT '0' COMMENT '签到时间',  PRIMARY KEY (`id`)  ) ENGINE=InnoDB DEFAULT CHARSET=utf8", "INSERT INTO shd_configuration (setting, value) VALUES ('check_is','1');", "INSERT INTO shd_configuration (setting, value) VALUES ('check_value','1.00');"];
        foreach ($sql as $v) {
            \think\Db::query($v);
        }
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>