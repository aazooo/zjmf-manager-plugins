<?php
return [["name" => "签到中心", "url" => "Check://Index/index", "fa_icon" => "bx bx-calendar", "lang" => ["chinese" => "签到中心", "chinese_tw" => "簽到中心", "english" => "Check in center"], "child" => []]];

?>