<?php
return [["name" => "签到设置", "url" => "Check://AdminIndex/config", "custom" => 0, "lang" => ["chinese" => "签到设置", "chinese_tw" => "簽到設置", "english" => "Check in settings"]], ["name" => "签到日志", "url" => "Check://AdminIndex/log", "custom" => 0, "lang" => ["chinese" => "签到日志", "chinese_tw" => "簽到日誌", "english" => "Check in record"]]];

?>