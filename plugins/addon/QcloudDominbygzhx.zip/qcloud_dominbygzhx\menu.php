<?php
return [["name" => "销售设置", "url" => "QcloudDominbygzhx://AdminIndex/index", "custom" => 0]];

?>