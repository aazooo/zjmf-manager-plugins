<?php
return [["name" => "销售设置", "url" => "QcloudCloudGzhx://AdminIndex/index", "custom" => 0]];

?>