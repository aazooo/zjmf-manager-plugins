<?php
return [["name" => "产品退款", "url" => "", "fa_icon" => "bx bx-slider-alt", "lang" => ["chinese" => "产品退款", "chinese_tw" => "產品退款", "english" => "Product Refund"], "child" => [["name" => "自助退款", "url" => "SelfRefund://Index/index", "fa_icon" => "bx bx-highlight", "lang" => ["chinese" => "申请退款", "chinese_tw" => "申請退款", "english" => "Request refund"], "child" => []]]]];

?>