<?php
return [["name" => "销售设置", "url" => "BizDominbygzhx://AdminIndex/index", "custom" => 0]];

?>