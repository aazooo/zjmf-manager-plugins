<?php
return [["name" => "设置", "url" => "InventorySynchronization://AdminIndex/setting", "custom" => 0, "lang" => ["chinese" => "功能设置", "chinese_tw" => "功能設置", "english" => "Setting"]], ["name" => "同步记录", "url" => "InventorySynchronization://AdminIndex/records", "custom" => 0, "lang" => ["chinese" => "同步记录", "chinese_tw" => "同步記錄", "english" => "Records"]]];

?>