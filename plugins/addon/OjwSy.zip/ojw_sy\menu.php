<?php
return [["name" => "上游列表", "url" => "OjwSy://AdminIndex/index", "custom" => 0]];

?>