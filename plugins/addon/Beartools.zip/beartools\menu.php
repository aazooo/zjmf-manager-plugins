<?php
return [["name" => "基础管理", "url" => "Beartools://AdminIndex/manage", "custom" => 0], ["name" => "高级管理", "url" => "Beartools://AdminIndex/highmanage", "custom" => 0]];

?>