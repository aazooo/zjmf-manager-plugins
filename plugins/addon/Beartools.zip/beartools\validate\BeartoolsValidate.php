<?php
namespace addons\beartools\validate;

class BeartoolsValidate extends \think\Validate
{
    protected $rule = ["uploadkey" => "require|varchar"];
    protected $message = ["uploadkey" => "不能为空|请填写复杂一些"];
}

?>