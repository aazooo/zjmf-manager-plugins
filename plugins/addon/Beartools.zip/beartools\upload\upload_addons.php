<?php
ini_set("upload_max_filesize", "200M");
ini_set("post_max_size", "201M");
ini_set("max_input_time", 320);
ini_set("memory_limit", "256M");
$path = $_SERVER["DOCUMENT_ROOT"] . "/plugins/addons/";
$extArr = ["zip"];
$file_path = dirname(__FILE__) . "/Upload.Key";
if (file_exists($file_path)) {
    $str = file_get_contents($file_path);
    $str = str_replace("\r\n", "<br />", $str);
}
if ($_SERVER["QUERY_STRING"] == $str) {
    if (isset($_POST) && $_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_FILES["file"]["name"];
        $size = $_FILES["file"]["size"];
        $ext = extend($name);
        $plugin_name = time() . rand(100, 999) . "." . $ext;
        $tmp = $_FILES["file"]["tmp_name"];
        if (move_uploaded_file($tmp, $path . $plugin_name)) {
            $zip = new ZipArchive();
            if ($zip->open($path . $plugin_name) === true) {
                $zip->extractTo($path);
                $zip->close();
                $arr["code"] = "上传成功~";
            }
        } else {
            $arr["code"] = "上传出现错误~";
            exit;
        }
    }
} else {
    $arr["code"] = "权限验证失败~";
}
echo json_encode($arr);
function extend($file_name)
{
    $extend = pathinfo($file_name);
    $extend = strtolower($extend["extension"]);
    return $extend;
}

?>