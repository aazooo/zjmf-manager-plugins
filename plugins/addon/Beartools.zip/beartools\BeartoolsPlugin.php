<?php
namespace addons\beartools;

class BeartoolsPlugin extends \app\admin\lib\Plugin
{
    public $info = ["name" => "Beartools", "title" => "魔方助手", "description" => "该插件能够方便您的日常管理。", "status" => 1, "author" => "BearStudio Team", "version" => "1.0", "module" => "addons"];
    public function install()
    {
        return true;
    }
    public function uninstall()
    {
        return true;
    }
}

?>