<?php
return ["module_name" => ["title" => "支付名称", "type" => "text", "value" => "USDT支付", "tip" => "友好的显示名称"], "epusdt_token" => ["title" => "EPUSDT密钥", "type" => "text", "value" => "", "tip" => "Epusdt的api接口认证token"], "epusdt_api" => ["title" => "EPUSDT接口", "type" => "text", "value" => "", "tip" => "Epusdt的api接口认证token"]];

?>