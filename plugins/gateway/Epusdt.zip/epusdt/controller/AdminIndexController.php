<?php
namespace gateways\ali_pay\controller;

class AdminIndexController extends \cmf\controller\PluginAdminBaseController
{
}

?>