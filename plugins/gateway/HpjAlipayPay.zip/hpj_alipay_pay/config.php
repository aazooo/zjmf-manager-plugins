<?php

return [
    'api_key' => [
        'title' => 'AppID',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'secret_key' => [
        'title' => 'AppSecret',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'gateway' => [
        'title' => '网关地址',
        'type' => 'text',
        'value' => 'https://api.xunhupay.com',
        'tip' => ''
    ]
];