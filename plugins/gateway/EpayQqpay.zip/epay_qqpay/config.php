<?php
return [
    'apiurl' => [
        'title' => '接口地址',
        'type'  => 'text',
        'value' => '',
        'tip'   => '必须以http://或https://开头，以/结尾',
    ],
    'pid' => [
        'title' => '商户ID',
        'type'  => 'text',
        'value' => '',
        'tip'   => '',
    ],
    'key' => [
        'title' => '商户密钥',
        'type'  => 'text',
        'value' => '',
        'tip'   => '',
    ],
];
