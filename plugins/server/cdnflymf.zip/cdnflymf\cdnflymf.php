<?php
function cdnflymf_idcsmartauthorizes()
{
}
function cdnflymf_AllowFunction()
{
    return ["client" => ["wzhcqk", "wzccgzon", "wzccgzoff", "wzccgzdel", "wzccgzput", "wzccglon", "wzccgloff", "wzccgldel", "wzccglput", "wzccppon", "wzccppoff", "wzccppdel", "wzccppput", "wzzssqput", "dnsapidel", "dnsapiput", "wzylcx", "wzglpostdx", "wzgziptype", "wzglwebsocket", "wzglgzip", "wzssll", "wzccsafe", "autoccsafe", "wzglhmd", "wzglbmd", "wzglpbdl", "wzglpbgw", "wzglmaxkxljtimeout", "wzglmaxkxlj", "wzglhyljc", "wzglhyhttpbb", "wzglhyym", "wzglfphy", "wzglaclid", "wzgldhcgz", "wzxgsslaqpz", "wzxgdhsts", "wzxgwzdocsp", "wzxgdwzhttpsport", "wzxgdqzhttps", "wzxgdhttp2", "wzxgdhydkys", "wzxgdyzfzfsxy", "wzxgdtimeout", "wzxgdyzsz", "wzxgdhttpshydk", "wzxgdhttphydk", "wzxgdhyxy", "wzxgdwzzs", "wzxgdjtdk", "wzxgym", "wzglxx", "wzgldel", "wzgloff", "wzglon", "wzglput", "l4xgzdyacl", "l4xgmracl", "l4xgljxz", "l4xgyzsz", "l4xgdstport", "l4xgyzfzjh", "l4xgprotocol", "l4xgjtdk", "l4zfxx", "l4del", "l4off", "l4on", "l4put", "wzzsdel", "wzzsoff", "wzzson", "wzzsput", "wzacldel", "wzacloff", "wzaclon", "wzaclput"], "admin" => []];
}
function cdnflymf_MetaData()
{
    return ["DisplayName" => "五洛云CDNFLY插件", "APIVersion" => "5.0", "HelpDoc" => "https://www.wuluoyun.com/"];
}
function cdnflymf_ConfigOptions()
{
    return [["type" => "text", "name" => "上架套餐ID", "description" => "请您填写需对接的套餐的ID，获取方法 1.咨询CDN平台客服获取；", "default" => "1", "key" => "package"]];
}
function cdnflymf_ClientArea($params)
{
    return ["wzgl" => ["name" => "网站管理"], "wzzs" => ["name" => "证书管理"], "sczf" => ["name" => "四层转发"], "wzhmd" => ["name" => "黑名单IP"], "wzjk" => ["name" => "网站监控"], "ylcx" => ["name" => "用量查询"], "dnsapi" => ["name" => "DNSAPI"]];
}
function cdnflymf_ClientAreaOutput($params, $key)
{
    if ($key == "wzgl") {
        return ["template" => "templates/wzguanl.html", "vars" => ["list" => cdnflymf_wzgl($params), "ccfh" => cdnflymf_wzccfh($params)]];
    }
    if ($key == "wzhmd") {
        return ["template" => "templates/wzheimd.html", "vars" => ["list" => cdnflymf_wzhmd($params)]];
    }
    if ($key == "wzzs") {
        return ["template" => "templates/wzzhengs.html", "vars" => ["list" => cdnflymf_wzzs($params), "wzlist" => cdnflymf_wzgl($params)]];
    }
    if ($key == "wzgz") {
        return ["template" => "templates/wzgz.html", "vars" => ["list" => cdnflymf_wzacl($params)]];
    }
    if ($key == "ccgz") {
        return ["template" => "templates/ccgz.html", "vars" => ["list" => cdnflymf_ccgzz($params)]];
    }
    if ($key == "ccpp") {
        return ["template" => "templates/ccpp.html", "vars" => ["list" => cdnflymf_ccppq($params)]];
    }
    if ($key == "ccgl") {
        return ["template" => "templates/ccgl.html", "vars" => ["list" => cdnflymf_ccglq($params)]];
    }
    if ($key == "wzjk") {
        return ["template" => "templates/wzjiank.html", "vars" => ["list" => cdnflymf_wzgl($params)]];
    }
    if ($key == "sczf") {
        return ["template" => "templates/sczhuanf.html", "vars" => ["list" => cdnflymf_l4zf($params)]];
    }
    if ($key == "ylcx") {
        return ["template" => "templates/ylchax.html", "vars" => ["list" => cdnflymf_wzgl($params)]];
    }
    if ($key == "dnsapi") {
        return ["template" => "templates/domainnsapi.html", "vars" => ["list" => cdnflymf_dnsapi($params)]];
    }
}
function cdnflymf_TestLink($params)
{
    $path = "/api-key";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result["status"] = 200;
        $result["data"]["server_status"] = 1;
    } else {
        $result["status"] = 200;
        $result["data"]["server_status"] = 0;
        $result["data"]["msg"] = "error";
    }
    return $result;
}
function cdnflymf_CreateAccount($params)
{
    $path = "/user-packages";
    $time = $params["billingcycle"] == "annually" ? "year" : substr($params["billingcycle"], 0, -2);
    $post = json_encode(["duration" => $time, "package" => $params["configoptions"]["package"], "name" => $params["domain"]]);
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $update["username"] = $array["data"];
        think\Db::name("host")->where("id", $params["hostid"])->update($update);
        $result["status"] = "success";
        $result["msg"] = $array["msg"];
    } else {
        $result["status"] = "error";
        $result["msg"] = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_TerminateAccount($params)
{
    $path = "/user-packages/" . $params["username"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result["status"] = "success";
        $result["msg"] = $array["msg"];
    } else {
        $result["status"] = "error";
        $result["msg"] = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_Renew($params)
{
    $path = "/user-packages/" . $params["username"];
    $time = $params["billingcycle"] == "annually" ? "year" : substr($params["billingcycle"], 0, -2);
    $post = json_encode(["duration" => $time]);
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result["status"] = "success";
        $result["msg"] = $array["msg"];
    } else {
        $result["status"] = "error";
        $result["msg"] = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_post($path, $post, $params)
{
    $url = "";
    if ($params["secure"]) {
        $url = "https://";
    } else {
        $url = "http://";
    }
    $url .= $params["server_ip"] ?: $params["server_host"];
    if (!empty($params["port"])) {
        $url .= ":" . $params["port"];
    }
    $url .= $path;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_HEADER, false);
    $headers = [];
    $headers[] = "Accept-Encoding:gzip, deflate";
    $headers[] = "api-key:" . $params["server_username"];
    $headers[] = "api-secret:" . $params["server_password"];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $body = curl_exec($ch);
    curl_close($ch);
    return $body;
}
function cdnflymf_get($path, $params)
{
    $url = "";
    if ($params["secure"]) {
        $url = "https://";
    } else {
        $url = "http://";
    }
    $url .= $params["server_ip"] ?: $params["server_host"];
    if (!empty($params["port"])) {
        $url .= ":" . $params["port"];
    }
    $url .= $path;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_HEADER, false);
    $headers = [];
    $headers[] = "Accept-Encoding:gzip, deflate";
    $headers[] = "api-key:" . $params["server_username"];
    $headers[] = "api-secret:" . $params["server_password"];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $body = curl_exec($ch);
    curl_close($ch);
    return $body;
}
function cdnflymf_del($path, $params)
{
    $url = "";
    if ($params["secure"]) {
        $url = "https://";
    } else {
        $url = "http://";
    }
    $url .= $params["server_ip"] ?: $params["server_host"];
    if (!empty($params["port"])) {
        $url .= ":" . $params["port"];
    }
    $url .= $path;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper("DELETE"));
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_HEADER, false);
    $headers = [];
    $headers[] = "Accept-Encoding:gzip, deflate";
    $headers[] = "api-key:" . $params["server_username"];
    $headers[] = "api-secret:" . $params["server_password"];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
function cdnflymf_put($path, $post, $params)
{
    $url = "";
    if ($params["secure"]) {
        $url = "https://";
    } else {
        $url = "http://";
    }
    $url .= $params["server_ip"] ?: $params["server_host"];
    if (!empty($params["port"])) {
        $url .= ":" . $params["port"];
    }
    $url .= $path;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper("PUT"));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_HEADER, false);
    $headers = [];
    $headers[] = "Accept-Encoding:gzip, deflate";
    $headers[] = "api-key:" . $params["server_username"];
    $headers[] = "api-secret:" . $params["server_password"];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
function cdnflymf_l4zf($params)
{
    $path = "/streams?user_package=" . $params["username"];
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $result = $array["data"];
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_l4put($params)
{
    $post = input("post.");
    $path = "/streams";
    $post = html_entity_decode("[{\"user_package\":\"" . $params["username"] . "\",\"listen\":[{\"protocol\":\"" . $post["type"] . "\",\"port\":\"" . $post["src_port"] . "\"}],\"backend_port\":\"" . $post["dst_port"] . "\",\"backend\":[{\"addr\":\"" . $post["address"] . "\"}]}]");
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4on($params)
{
    $post = input("post.");
    $path = "/streams";
    $post = json_encode(["id" => $post["id"], "enable" => 1]);
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4off($params)
{
    $post = input("post.");
    $path = "/streams";
    $post = json_encode(["id" => $post["id"], "enable" => 0]);
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4del($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzzs($params)
{
    $path = "/certs?des=" . $params["domain"];
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $result = $array["data"];
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_wzzson($params)
{
    $post = input("post.");
    $path = "/certs";
    $post = json_encode(["id" => $post["id"], "enable" => 1]);
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzzsoff($params)
{
    $post = input("post.");
    $path = "/certs";
    $post = json_encode(["id" => $post["id"], "enable" => 0]);
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzzsdel($params)
{
    $post = input("post.");
    $path = "/certs/" . $post["id"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzzsput($params)
{
    $post = input("post.");
    $path = "/certs";
    $post = json_encode(["name" => $post["name"], "des" => $params["domain"], "cert" => $post["cert"], "key" => $post["key"], "type" => "custom"]);
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzacl($params)
{
    $path = "/acls";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $result = [];
        foreach ($array["data"] as $aclid => $acldata) {
            if ($acldata["des"] == $params["domain"]) {
                $result[] = $acldata;
            }
        }
        if (sizeof($result) === 0) {
            $result = "count";
        }
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_wzaclon($params)
{
    $post = input("post.");
    $path = "/acls";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":1}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzacloff($params)
{
    $post = input("post.");
    $path = "/acls";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":0}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzacldel($params)
{
    $post = input("post.");
    $path = "/acls/" . $post["id"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzaclput($params)
{
    $post = input("post.");
    $path = "/acls";
    $post = html_entity_decode("{\"name\":\"" . $post["name"] . "\",\"des\":\"" . $params["domain"] . "\",\"data\":" . $post["code"] . ",\"default_action\":\"" . $post["type"] . "\"}");
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgport($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = html_entity_decode("{\"listen\":[" . $post["code"] . "]}");
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4zfxx($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["data"]) ? $array["data"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgjtdk($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = html_entity_decode("{\"listen\":" . $post["data"] . "}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgprotocol($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = "{\"proxy_protocol\":" . $post["data"] . "}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgyzfzjh($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = "{\"balance_way\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgdstport($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = "{\"backend_port\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgyzsz($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = html_entity_decode("{\"backend\":" . $post["data"] . "}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgljxz($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = "{\"conn_limit\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgmracl($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = "{\"acl\":{\"default_action\":\"" . $post["data"] . "\"}}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_l4xgzdyacl($params)
{
    $post = input("post.");
    $path = "/streams/" . $post["id"];
    $post = html_entity_decode("{\"acl\":{\"rule\":" . $post["data"] . "}}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzgl($params)
{
    $path = "/sites?user_package=" . $params["username"];
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $result = $array["data"];
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_wzglon($params)
{
    $post = input("post.");
    $path = "/sites";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":1}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzgloff($params)
{
    $post = input("post.");
    $path = "/sites";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":0}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzgldel($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglput($params)
{
    $post = input("post.");
    $path = "/sites";
    $post = "[{\"user_package\":\"" . $params["username"] . "\",\"domain\":\"" . $post["domain"] . "\",\"http_listen\":{\"port\":\"80\"},\"backend\":[{\"addr\":\"" . $post["dstip"] . "\"}],\"backend_http_port\":\"" . $post["dstport"] . "\"}]";
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglxx($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["data"]) ? $array["data"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgym($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"domain\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdjtdk($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"http_listen\":{\"port\":\"" . $post["data"] . "\"}}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdwzzs($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    if ($post["data"] == 0) {
        $post = "{\"https_listen\":{}}";
    } else {
        $post = "{\"https_listen\":{\"cert\":\"" . $post["data"] . "\"}}";
    }
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdhyxy($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"backend_protocol\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdhttphydk($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"backend_http_port\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdhttpshydk($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"backend_https_port\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdyzsz($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"backend\":" . $post["data"] . "}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdtimeout($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"proxy_timeout\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdyzfzfsxy($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"balance_way\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdhydkys($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"backend_port_mapping\":" . $post["data"] . "}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdhsts($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"https_listen\":{\"hsts\":" . $post["data"] . "}}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdhttp2($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"https_listen\":{\"http2\":" . $post["data"] . "}}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdqzhttps($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"https_listen\":{\"force_ssl_enable\":" . $post["data"] . "}}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgdwzhttpsport($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"https_listen\":{\"force_ssl_port\":\"" . $post["data"] . "\"}}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgwzdocsp($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"https_listen\":{\"ocsp_stapling\":" . $post["data"] . "}}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzxgsslaqpz($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"https_listen\":{\"ssl_protocols\":\"" . $post["a"] . "\",\"ssl_ciphers\":\"" . $post["b"] . "\",\"ssl_prefer_server_ciphers\":\"" . $post["c"] . "\"}}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzgldhcgz($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"proxy_cache\":" . $post["data"] . "}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglaclid($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"acl\":" . $post["data"] . "}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglfphy($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"range\":" . $post["data"] . "}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglhyym($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"backend_host\":\"" . $post["data"] . "\"}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglhyhttpbb($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"proxy_http_version\":\"" . $post["data"] . "\"}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglhyljc($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"ups_keepalive\":" . $post["data"] . "}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglmaxkxlj($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"ups_keepalive_conn\":\"" . $post["data"] . "\"}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglmaxkxljtimeout($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = html_entity_decode("{\"ups_keepalive_timeout\":\"" . $post["data"] . "\"}");
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccfh($params)
{
    $path = "/cc-rules?internal_self=1";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $result = $array["data"];
        if (sizeof($result) === 0) {
            $result = "count";
        }
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_wzglpbgw($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    if ($post["data"] == "true") {
        $post = "{\"block_region\":\"mn,kp,kr,jp,vn,la,kh,th,mm,my,sg,id,bn,ph,tl,in,bd,bt,np,pk,lk,mv,sa,qa,bh,kw,ae,om,ye,ge,lb,sy,il,ps,jo,iq,ir,af,cy,az,tm,tj,kg,uz,kz,dz,ao,bj,bw,bf,bi,cm,cv,cf,td,km,ci,cd,dj,eg,gq,er,et,ga,gm,gh,gn,gw,ke,ls,lr,ly,mg,mw,ml,mr,mu,ma,mz,na,ne,ng,cg,rw,st,sn,sc,sl,so,za,sd,ss,tz,tg,tn,ug,zm,zw,ag,bs,bb,bz,ca,cr,cu,dm,do,sv,ai,bm,gl,gd,gp,gt,ht,hn,jm,mq,mx,ms,aw,cw,ni,pa,kn,lc,vc,tt,tc,us,mf,pr,bl,sx,ar,bo,br,cl,co,ec,gy,py,pe,sr,uy,ve,al,ad,am,at,by,be,ba,bg,hr,cz,dk,ee,fi,fr,de,gr,hu,is,ie,it,lv,li,lt,lu,mk,mt,md,mc,me,nl,no,pl,pt,ro,ru,sm,rs,sk,si,es,se,ch,tr,ua,uk,va,au,pg,nz,fj,sb,pf,nc,vu,ws,gu,fm,to,ki,as,pw,wf,nr,tv,nu,tk\"}";
    } else {
        $post = "{\"block_region\":\"\"}";
    }
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglpbdl($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"block_proxy\":" . $post["data"] . "}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccsafe($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"cc_default_rule\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglhmd($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = json_encode(["black_ip" => $post["data"]]);
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglbmd($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = json_encode(["white_ip" => $post["data"]]);
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_autoccsafe($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    if (isset($post["time"]) && isset($post["mod"])) {
        $post = "{\"cc_switch\":{\"rule\":\"" . $post["mod"] . "\",\"switch\":\"" . $post["time"] . "\",\"enable\":1}}";
    } else {
        $post = "{\"cc_switch\":{}}";
    }
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzssll($params)
{
    $post = input("post.");
    date_default_timezone_set("PRC");
    $time = time();
    $time0 = date("Y-m-d H:i:s", $time - 3600);
    $time1 = date("Y-m-d H:i:s", $time);
    $path = "/monitor/site/realtime?type=" . $post["type"] . "&start=" . urlencode($time0) . "&end=" . urlencode($time1) . "&domain=" . $post["domain"] . "&port=";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $num = sizeof($array["data"]);
        $return = [];
        foreach ($array["data"] as $id => $value) {
            $return[] = $value[1];
        }
        $result = ["msg" => $return];
    } else {
        $result = "error";
    }
    return $result;
}
function cdnflymf_wzglgzip($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"gzip_enable\":" . $post["data"] . "}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglwebsocket($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"websocket_enable\":" . $post["data"] . ",\"ups_keepalive\":0}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzgziptype($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"gzip_types\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzglpostdx($params)
{
    $post = input("post.");
    $path = "/sites/" . $post["id"];
    $post = "{\"post_size_limit\":\"" . $post["data"] . "\"}";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzylcx($params)
{
    $post = input("post.");
    date_default_timezone_set("PRC");
    $time = time();
    $day = $post["time"] * 86400;
    $time0 = date("Y-m-d", $time - $day + 86400);
    $time1 = date("Y-m-d", $time + 86400);
    if ($post["domain"] == "all") {
        $domain = "";
    } else {
        $domain = $post["domain"];
    }
    $path = "/monitor/usage?cate=site&type=" . $post["type"] . "&start=" . urlencode($time0) . "&end=" . urlencode($time1) . "&res=" . $domain . "&user_package=" . $params["username"];
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = $array;
    } else {
        $result = "error";
    }
    return $result;
}
function cdnflymf_dnsapi($params)
{
    $path = "/dnsapis";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $v = [];
        foreach ($array["data"] as $id => $value) {
            if ($value["des"] == $params["domain"]) {
                $v[] = $value;
            }
        }
        if (sizeof($v) === 0) {
            $result = "count";
        } else {
            $result = $v;
        }
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_dnsapidel($params)
{
    $post = input("post.");
    $path = "/dnsapis/" . $post["id"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_dnsapiput($params)
{
    $post = input("post.");
    $path = "/dnsapis";
    $post = "{\"name\":\"" . $post["name"] . "\",\"des\":\"" . $params["domain"] . "\",\"type\":\"" . $post["type"] . "\",\"auth\":{" . html_entity_decode($post["auth"]) . "}}";
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzzssqput($params)
{
    $post = input("post.");
    $path = "/certs";
    $post = json_encode(["name" => $post["name"], "des" => $params["domain"], "dnsapi" => $post["dnsapi"], "domain" => $post["domain"], "type" => $post["type"]]);
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_ccppq($params)
{
    $path = "/cc-matchs?internal_self=1";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $result = [];
        foreach ($array["data"] as $aclid => $acldata) {
            if ($acldata["des"] == $params["domain"] || $acldata["des"] == "内置匹配器") {
                $result[] = $acldata;
            }
        }
        if (sizeof($result) === 0) {
            $result = "count";
        }
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_wzccppon($params)
{
    $post = input("post.");
    $path = "/cc-matchs";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":1}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccppoff($params)
{
    $post = input("post.");
    $path = "/cc-matchs";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":0}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccppdel($params)
{
    $post = input("post.");
    $path = "/cc-matchs/" . $post["id"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccppput($params)
{
    $post = input("post.");
    $path = "/cc-matchs";
    $post = html_entity_decode("{\"name\":\"" . $post["name"] . "\",\"des\":\"" . $params["domain"] . "\",\"data\":" . $post["code"] . "}");
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $post;
}
function cdnflymf_ccglq($params)
{
    $path = "/cc-filters?internal_self=1";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $result = [];
        foreach ($array["data"] as $aclid => $acldata) {
            if ($acldata["des"] == $params["domain"] || $acldata["des"] == "内置过滤器") {
                $result[] = $acldata;
            }
        }
        if (sizeof($result) === 0) {
            $result = "count";
        }
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_wzccglon($params)
{
    $post = input("post.");
    $path = "/cc-filters";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":1}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccgloff($params)
{
    $post = input("post.");
    $path = "/cc-filters";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":0}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccgldel($params)
{
    $post = input("post.");
    $path = "/cc-filters/" . $post["id"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccglput($params)
{
    $post = input("post.");
    $path = "/cc-filters";
    $post = html_entity_decode("{\"name\":\"" . $post["name"] . "\",\"des\":\"" . $params["domain"] . "\",\"type\":\"" . $post["type"] . "\",\"within_second\":\"" . $post["time"] . "\",\"max_req\":\"" . $post["num"] . "\",\"max_req_per_uri\":\"0\",\"extra\":{}}");
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_ccgzz($params)
{
    $path = "/cc-rules?internal_self=1";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        if (isset($array["count"]) && $array["count"] === 0) {
            $result = "count";
        }
        $result = [];
        foreach ($array["data"] as $aclid => $acldata) {
            if ($acldata["des"] == $params["domain"] || $acldata["des"] == "内置规则") {
                $result[] = $acldata;
            }
        }
        if (sizeof($result) === 0) {
            $result = "count";
        }
    } else {
        $result = "count";
    }
    return $result;
}
function cdnflymf_wzccgzon($params)
{
    $post = input("post.");
    $path = "/cc-rules";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":1}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccgzoff($params)
{
    $post = input("post.");
    $path = "/cc-rules";
    $post = "[{\"id\":" . $post["id"] . ",\"enable\":0}]";
    $json = cdnflymf_put($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccgzdel($params)
{
    $post = input("post.");
    $path = "/cc-rules/" . $post["id"];
    $json = cdnflymf_del($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzccgzput($params)
{
    $post = input("post.");
    $path = "/cc-rules";
    $post = html_entity_decode("{\"name\":\"" . $post["name"] . "\",\"des\":\"" . $params["domain"] . "\",\"data\":" . $post["code"] . ",\"sort\":\"1\",\"is_show\":true}");
    $json = cdnflymf_post($path, $post, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzhcqk($params)
{
    $post = input("post.");
    $path = "/jobs";
    $posts = html_entity_decode("{\"type\":\"clean_dir\",\"data\":{\"url\":\"" . $post["domain"] . "\"}}");
    $json = cdnflymf_post($path, $posts, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}
function cdnflymf_wzhmd($params)
{
    $post = input("post.");
    $path = "/monitor/site/blackip?page=1&limit=1000000";
    $json = cdnflymf_get($path, $params);
    $array = json_decode($json, true);
    if (isset($array["code"]) && $array["code"] === 0) {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    } else {
        $result = isset($array["msg"]) ? $array["msg"] : "error";
    }
    return $result;
}

?>