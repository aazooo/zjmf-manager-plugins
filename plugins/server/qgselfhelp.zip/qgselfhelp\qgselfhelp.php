<?php
function qgselfhelp_idcsmartauthorizes()
{
}
function qgselfhelp_MetaData()
{
    return ["DisplayName" => "自助开通模块", "APIVersion" => "1.1", "HelpDoc" => "https://hy.baota.host/"];
}
function qgselfhelp_ConfigOptions()
{
    return [["type" => "textarea", "name" => "面板链接地址", "default" => "", "key" => "qgselfhelp_url"], ["type" => "textarea", "name" => "开通前公告内容", "default" => "", "key" => "qgselfhelp_gg1"], ["type" => "yesno", "name" => "是否购买就激活开通", "description" => "勾选则表示为：购买就激活开通   ，不选为：待开通", "default" => "0", "key" => "qgselfhelp_jh"], ["type" => "textarea", "name" => "开通后公告内容", "default" => "", "key" => "qgselfhelp_gg2"], ["type" => "dropdown", "name" => "显示面板链接地址", "options" => "显示", "default" => "显示", "key" => "qgselfhelp_open"], ["type" => "text", "name" => "备注内容", "description" => "前台不显示的内容", "default" => "", "key" => "qgselfhelp_gg3"], ["type" => "dropdown", "name" => "显示面板样式", "options" => "样式1,样式2,样式3", "default" => "样式1", "key" => "qgselfhelp_css"]];
}
function qgselfhelp_TestLink($params)
{
    $canshu0 = "0";
    $canshu3 = "失败";
    if (isset($canshu0) && $canshu0 == 0) {
        $result["status"] = 200;
        $result["data"]["server_status"] = 1;
    } else {
        $result["status"] = 200;
        $result["data"]["server_status"] = 0;
        $result["data"]["msg"] = $canshu3;
    }
    return $result;
}
function qgselfhelp_ClientAreaOutput($params, $key)
{
    $user_server = $params["domain"];
    $vserverid = $params["user_info"]["phonenumber"];
    $phone = $params["user_info"]["phonenumber"];
    $email = $params["user_info"]["email"];
    if ($key == "add") {
        if ($params["password"] == "") {
            $gg = $params["configoptions"]["qgselfhelp_gg1"];
        } else {
            $gg = $params["configoptions"]["qgselfhelp_gg2"];
        }
        return ["template" => "templates/soft_cx.html", "vars" => ["user" => $params["username"], "pass" => $params["password"], "url" => $params["configoptions"]["qgselfhelp_url"], "gg" => $gg, "ip" => $params["dedicatedip"], "css" => $params["configoptions"]["qgselfhelp_css"]]];
    }
    if ($key == "ho") {
        return ["template" => "templates/shuoming.html", "vars" => ["bz" => $params["configoptions"]["qgselfhelp_bz"]]];
    }
}
function qgselfhelp_ClientArea($params)
{
    return ["add" => ["name" => "产品信息"]];
}
function qgselfhelp_CreateAccount($params)
{
    $xx = $params["configoptions"]["qgselfhelp_jh"];
    if ($xx == "1") {
        $update["dedicatedip"] = "已激活,机器正在上架中请等待！";
        $update["username"] = "用户名和密码，添加中请稍后";
        $update["password"] = "";
        Db::name("host")->where("id", $params["hostid"])->update($update);
        return "ok";
    }
    return ["status" => "error", "msg" => "开通失败:请手动激活"];
}

?>