<?php
function agent_idcsmartauthorizes()
{
}
function agent_MetaData()
{
    return ["DisplayName" => "代理自助购买模块", "APIVersion" => "1.0.0", "HelpDoc" => "http://blog.vpser.ink/index.php/archives/29/"];
}
function agent_ConfigOptions()
{
    $groups = think\Db::name("client_groups")->select()->toArray();
    $names = array_column($groups, "group_name", "id");
    if ($names) {
        $status = "【成功】";
    } else {
        $status = "【失败】";
    }
    return [["type" => "dropdown", "name" => "选择要升级的分组", "options" => $names, "description" => "自动获取" . $status, "key" => "group"], ["type" => "dropdown", "name" => "余额是否退回账户", "options" => ["否", "是"], "key" => "is_pay"]];
}
function agent_TestLink($params)
{
    $result["status"] = 200;
    $result["data"]["server_status"] = 1;
    return $result;
}
function agent_Status($params)
{
    $result["status"] = "success";
    $result["data"]["status"] = "on";
    $result["data"]["des"] = "正常";
    return $result;
}
function agent_CreateAccount($params)
{
    $user = think\Db::name("clients")->find($params["uid"]);
    $host = think\Db::name("host")->find($params["hostid"]);
    $update["groupid"] = $params["configoptions"]["group"];
    if ($params["configoptions"]["is_pay"] == "1") {
        $update["credit"] = $user["credit"] + $host["firstpaymentamount"];
    }
    $sql = think\Db::name("clients")->where("id", $params["uid"])->update($update);
    if ($sql) {
        $update2["domainstatus"] = "Active";
        think\Db::name("host")->where("id", $params["hostid"])->update($update2);
        return "success";
    }
    return ["status" => "error", "msg" => "开通失败"];
}
function agent_Cancel($params)
{
    $update["groupid"] = NULL;
    $sql = think\Db::name("clients")->where("id", $params["uid"])->update($update);
    if ($sql) {
        return ["status" => "success", "msg" => "取消成功"];
    }
    return ["status" => "error", "msg" => "取消失败"];
}
function agent_AdminButton($params)
{
    $button = ["Cancel" => "取消代理资格"];
    return $button;
}

?>