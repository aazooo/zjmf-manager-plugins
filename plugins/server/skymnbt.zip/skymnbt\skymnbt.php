<?php
function skymnbt_idcsmartauthorizes()
{
}
function skymnbt_MetaData()
{
    return ["DisplayName" => "梦奈宝塔", "APIVersion" => "2.0.0", "HelpDoc" => "http://www.wxin.net/"];
}
function skymnbt_ConfigOptions()
{
    return [["type" => "text", "name" => "Web空间大小", "description" => "MB", "key" => "a1"], ["type" => "text", "name" => "Sql空间大小", "description" => "MB", "key" => "a2"], ["type" => "text", "name" => "流量限制", "description" => "GB/月", "key" => "a3"], ["type" => "text", "name" => "产品类型", "description" => "1为CDN，2为主机", "key" => "a4"], ["type" => "text", "name" => "绑定域名数", "description" => "个，0为无限", "key" => "a5"], ["type" => "text", "name" => "备注", "description" => "用于前台显示", "key" => "note"]];
}
function skymnbt_TestLink($params)
{
    $url = skymnbt_getHttpPrefix($params, "cfif");
    $postdata = ["username" => "mnbt_link"];
    $resultdata = skymnbt_send_post($params, $url, $postdata);
    if ($resultdata["code"] != "200") {
        return ["status" => "200", "data" => ["server_status" => 0, "msg" => $resultdata["msg"]]];
    }
    return ["status" => "200", "data" => ["server_status" => 1]];
}
function skymnbt_CreateAccount($params)
{
    if ($params["configoptions"]["a1"] == NULL || $params["configoptions"]["a2"] == NULL || $params["configoptions"]["a3"] == NULL || $params["configoptions"]["a4"] == NULL || $params["configoptions"]["a5"] == NULL) {
        return "参数设置错误，请检查";
    }
    if (empty($params["password"])) {
        $sys_pwd = randStr(8);
    } else {
        $sys_pwd = $params["password"];
    }
    $url = skymnbt_getHttpPrefix($params, "kt");
    $postdata = ["username" => $params["domain"], "password" => $sys_pwd, "webdx" => $params["configoptions"]["a1"], "sqldx" => $params["configoptions"]["a2"], "sizemax" => $params["configoptions"]["a3"], "type" => $params["configoptions"]["a4"], "ymbds" => $params["configoptions"]["a5"], "dqtime" => 0];
    $resultdata = skymnbt_send_post($params, $url, $postdata);
    if ($resultdata["code"] != "200") {
        return ["code" => "error", "msg" => $resultdata["msg"]];
    }
    $update = ["password" => cmf_encrypt($sys_pwd), "dedicatedip" => $params["server_ip"], "username" => $params["domain"]];
    think\Db::name("host")->where("id", $params["hostid"])->update($update);
    return "success";
}
function skymnbt_SuspendAccount($params)
{
    $url = skymnbt_getHttpPrefix($params, "zt");
    $postdata = ["username" => $params["username"]];
    $resultdata = skymnbt_send_post($params, $url, $postdata);
    if ($resultdata["code"] != "200") {
        return ["code" => "error", "msg" => $resultdata["msg"]];
    }
    return "success";
}
function skymnbt_UnSuspendAccount($params)
{
    $url = skymnbt_getHttpPrefix($params, "jc");
    $postdata = ["username" => $params["username"]];
    $resultdata = skymnbt_send_post($params, $url, $postdata);
    if ($resultdata["code"] != "200") {
        return ["code" => "error", "msg" => $resultdata["msg"]];
    }
    return "success";
}
function skymnbt_TerminateAccount($params)
{
    $url = skymnbt_getHttpPrefix($params, "tz");
    $postdata = ["username" => $params["username"]];
    $resultdata = skymnbt_send_post($params, $url, $postdata);
    if ($resultdata["code"] != "200") {
        return ["code" => "error", "msg" => $resultdata["msg"]];
    }
    return "success";
}
function skymnbt_CrackPassword($params, $new_pass)
{
    $url = skymnbt_getHttpPrefix($params, "czmm");
    $postdata = ["username" => $params["username"], "password" => $new_pass];
    $resultdata = skymnbt_send_post($params, $url, $postdata);
    if ($resultdata["code"] != "200") {
        return ["code" => "error", "msg" => $resultdata["msg"]];
    }
    return "success";
}
function skymnbt_ClientArea($params)
{
    return ["msgrmation" => ["name" => "产品详情"]];
}
function skymnbt_ClientAreaOutput($params, $key)
{
    if ($key == "msgrmation") {
        $url = skymnbt_getHttpPrefix($params, "logine");
        return ["template" => "templates/information.html", "vars" => ["url" => $url, "product_name" => $params["name"], "username" => $params["username"], "password" => $params["password"], "note" => $params["configoptions"]["note"]]];
    }
}
function skymnbt_send_post($params, $url, $post_data)
{
    $post_data["mn_bh"] = $params["server_ip"];
    $post_data["mn_key"] = $params["server_password"];
    $post_data["mn_keye"] = $params["server_username"];
    $post_data["mn_vs"] = "17";
    $postdata = http_build_query($post_data);
    $options = ["http" => ["method" => "POST", "header" => "Content-type:application/x-www-form-urlencoded", "content" => $postdata, "timeout" => 900]];
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return json_decode($result, true);
}
function skymnbt_getHttpPrefix($params, $endpoint)
{
    if ($endpoint == "logine") {
        $path = "/user/idcdl";
    } else {
        $path = "/api/api";
    }
    $path .= ".php?gn=" . $endpoint;
    return $params["server_host"] . $path;
}

?>