<?php
function xqxcy_idcsmartauthorizes()
{
}
function xqxcy_MetaData()
{
    return ["DisplayName" => "小储云自助授权模块", "APIVersion" => "1.0.0", "HelpDoc" => "http://idc.888niu.cn/knowledgebaseview?id=1"];
}
function xqxcy_ConfigOptions()
{
    return [["type" => "text", "name" => "对接密钥", "description" => "小储云服务端对接密钥，到这里查看：https://cdn.79tian.com/api/wxapi/view/index.php找到对接文档那里查看", "key" => "a1"], ["type" => "dropdown", "name" => "方式", "description" => "对接方式", "options" => ["1" => "授权", "2" => "开通代理商", "3" => "开通授权商", "4" => "代理商升级授权商"], "default" => "1", "key" => "a2"], ["type" => "text", "name" => "备注", "description" => "用于前台显示", "key" => "note"]];
}
function xqxcy_CreateAccount($params)
{
    if ($params["configoptions"]["a1"] == NULL) {
        return "参数设置错误，请检查";
    }
    if (empty($params["password"])) {
        $sys_pwd = randStr(8);
    } else {
        $sys_pwd = $params["password"];
    }
    if ($params["port"] == 443 || $params["secure"]) {
        $http = "https://";
    } else {
        $http = "http://";
    }
    $url = "https://cdn.79tian.com/api/Accredit/index.php";
    $postdata = ["token" => $params["configoptions"]["a1"], "qq" => $params["customfields"]["qq"], "domain" => $params["customfields"]["域名"], "type" => $params["configoptions"]["a2"]];
    $resultdata = request_post($url, $postdata);
    $resultdata = json_decode($resultdata, true);
    if ($resultdata["code"] != 1) {
        return ["code" => "error", "msg" => $resultdata["msg"]];
    }
    $update["password"] = cmf_encrypt($sys_pwd);
    $update["dedicatedip"] = $params["server_ip"];
    $update["username"] = $params["domain"];
    think\Db::name("host")->where("id", $params["hostid"])->update($update);
    return "success";
}
function xqxcy_ClientArea($params)
{
    return ["msgrmation" => ["name" => "产品详情"]];
}
function xqxcy_ClientAreaOutput($params, $key)
{
    if ($key == "msgrmation") {
        if ($params["port"] == 443 || $params["secure"]) {
            $http = "https://";
        } else {
            $http = "http://";
        }
        $url = "https://cdn.79tian.com/api/wxapi/view/login.php?condition=1";
        return ["template" => "templates/information.html", "vars" => ["url" => $url, "product_name" => $params["name"], "username" => $params["customfields"]["qq"], "password" => $params["customfields"]["域名"], "note" => $params["configoptions"]["note"]]];
    }
}

?>