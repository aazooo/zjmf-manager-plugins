<?php
function smsnvo_idcsmartauthorizes()
{
}
function smsnvo_MetaData()
{
    return ["DisplayName" => "产品人工开通插件", "APIVersion" => "1.0", "HelpDoc" => "帮助文档"];
}
function smsnvo_TestLink(array $params)
{
    $result = [];
    $result["status"] = 200;
    $result["data"]["server_status"] = 1;
    $result["data"]["msg"] = " ";
    return $result;
}
function smsnvo_ConfigOptions()
{
    return [["type" => "textarea", "placeholder" => "请输入插件的登陆地址", "name" => "比如http://ip:3312", "description" => "用户对应的登陆地址", "rows" => 1, "cols" => 10, "key" => "url"]];
}
function smsnvo_SuspendAccount()
{
    return "success";
}
function smsnvo_CreateAccount()
{
    return "success";
}
function smsnvo_UnsuspendAccount()
{
    return "success";
}
function smsnvo_TerminateAccount()
{
    return "success";
}
function smsnvo_ClientArea($params)
{
    return ["information" => ["name" => "产品信息"]];
}
function smsnvo_ClientAreaOutput($params, $key)
{
    if ($key == "information") {
        return ["template" => "templates/information.html", "vars" => ["username" => $params["username"], "password" => $params["password"], "product_name" => $params["domain"], "url" => $params["configoptions"]["url"]]];
    }
}

?>