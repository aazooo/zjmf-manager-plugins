<?php
return ["act" => ["title" => "发信平台", "type" => "select", "options" => ["tj" => "天迹企业邮"], "value" => "", "tip" => ""], "name" => ["title" => "发信邮件名", "type" => "text", "value" => "", "tip" => ""], "username" => ["title" => "发信平台用户名", "type" => "text", "value" => "", "tip" => ""], "Key" => ["title" => "发信平台Key", "type" => "text", "value" => "", "tip" => ""]];

?>