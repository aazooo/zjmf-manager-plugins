<?php

return [
    'AppId' => [
        'title' => 'AppId',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'AppKey' => [
        'title' => 'AppKey',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'fromname' => [
        'title' => '系统邮件名',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ],
    'systememail' => [
        'title' => '系统邮箱名',
        'type' => 'text',
        'value' => '',
        'tip' => ''
    ]
];