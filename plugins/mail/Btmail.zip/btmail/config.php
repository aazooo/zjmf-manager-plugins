<?php
return ["host" => ["title" => "宝塔链接", "type" => "text", "value" => "", "tip" => "例如：http://127.0.0.1:8888"], "username" => ["title" => "发件地址", "type" => "text", "value" => "", "tip" => "例如：system@test.com"], "password" => ["title" => " 邮箱密码", "type" => "text", "value" => "", "tip" => ""]];

?>